package ch.epfl.javelo.routing;

import ch.epfl.javelo.Math2;
import ch.epfl.javelo.Preconditions;

import java.util.Arrays;

public final class ElevationProfileComputer {

    private ElevationProfileComputer(){}

    /**
     * @param route
     * @param maxStepLength
     * @return le profil en long de l'itinéraire route,
     * en garantissant que l'espacement entre les échantillons du profil est d'au maximum maxStepLength mètres
     */
    public static ElevationProfile elevationProfile(Route route, double maxStepLength){
        Preconditions.checkArgument(maxStepLength>0);
        int sampleNumber = (int)Math.ceil(route.length()/maxStepLength) + 1;
        float[] samples = new float[sampleNumber];
        double delta  = route.length()/(sampleNumber-1);
        for(int i = 0; i<sampleNumber; i++){
            samples[i] = (float) route.elevationAt(i*delta);
        }

        int indexFirstNumber = 0;
        while(Float.isNaN(samples[indexFirstNumber]) && indexFirstNumber < sampleNumber){
            indexFirstNumber++;
            if(indexFirstNumber == sampleNumber){
                indexFirstNumber = -1;
            }
        }
        int indexLastNumber = sampleNumber-1;
        while(Float.isNaN(samples[indexLastNumber]) && indexLastNumber > -1){
            indexLastNumber--;
            if(indexLastNumber == -1){
                indexLastNumber = -1;
            }
        }

        if(indexFirstNumber == -1) {
            Arrays.fill(samples, 0, sampleNumber - 1, 0);
        }
        if(indexFirstNumber > 0){
            Arrays.fill(samples, 0, indexFirstNumber-1, samples[indexFirstNumber]);
        }
        if(indexLastNumber < sampleNumber-1 && indexLastNumber > 0){
            Arrays.fill(samples, indexLastNumber + 1 , sampleNumber-1, samples[indexLastNumber]);
        }

        for(int i = 0; i < sampleNumber; i++){
            if(Float.isNaN(samples[i])){
                int intialindex = i-1;
                int finalIndex = i;
                while(Float.isNaN(samples[finalIndex])){
                    finalIndex++;
                }
                samples[i] = (float) Math2.interpolate(samples[intialindex], samples[finalIndex], 1/(finalIndex-intialindex));
            }
        }
        return new ElevationProfile(route.length(), samples);
    }
}
