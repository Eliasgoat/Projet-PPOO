package ch.epfl.javelo.routing;

import ch.epfl.javelo.Functions;
import ch.epfl.javelo.Preconditions;
import java.util.DoubleSummaryStatistics;

public final class ElevationProfile{

    private final double length;
    private final float[] elevationSamples;

    public ElevationProfile(double length, float[] elevationSamples){
        Preconditions.checkArgument(length>0 && elevationSamples.length>=2);
        this.length = length;
        this.elevationSamples = elevationSamples;
    }

    /**
     * @return la longueur du profil, en mètres
     */
    public double length() {
        return length;
    }

    /**
     * @return l'altitude minimum du profil, en mètres
     */
    public double minElevation() {
        DoubleSummaryStatistics s = new DoubleSummaryStatistics();
        for(int i = 0; i< elevationSamples.length; i++){
            s.accept(elevationSamples[i]);
        }
        return s.getMin();
    }

    /**
     * @return l'altitude maximum du profil, en mètres
     */
    public double maxElevation() {
        DoubleSummaryStatistics s = new DoubleSummaryStatistics();

        for(int i = 0; i< elevationSamples.length; i++){
            s.accept(elevationSamples[i]);
        }
        return s.getMax();
    }

    /**
     * @return le dénivelé positif total du profil, en mètres
     */
    public double totalAscent() {
        double totalAscent = 0;
        for(int i = 1; i<elevationSamples.length; i++){
            if((elevationSamples[i]- elevationSamples[i-1])>= 0){
                totalAscent += elevationSamples[i] - elevationSamples[i-1];
            }
        }
        return totalAscent;
    }

    /**
     * @return le dénivelé négatif total du profil, en mètres
     */
    public double totalDescent() {
        double totalDescent = 0;
        for(int i = 1; i<elevationSamples.length; i++){
            if((elevationSamples[i]- elevationSamples[i-1])<= 0){
                totalDescent += elevationSamples[i-1] - elevationSamples[i];
            }
        }
        return totalDescent;
    }

    /**
     * @param position position donnée
     * @return l'altitude du profil à la position donnée
     */
    public double elevationAt(double position) {
        return Functions.sampled(elevationSamples, length).applyAsDouble(position);
    }
}
