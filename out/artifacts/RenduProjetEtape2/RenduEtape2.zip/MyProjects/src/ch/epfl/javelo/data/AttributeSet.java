package ch.epfl.javelo.data;

import ch.epfl.javelo.Preconditions;

import java.util.StringJoiner;

public record AttributeSet(long bits) {

    public AttributeSet{
        Preconditions.checkArgument((bits>=0)&& (bits<(long)Math.pow(2, 62)));
    }

    /**
     * Retourne un ensemble contenant uniquement les attributs donnés en argument
     * @param attributes ensemble des attributs que le (new AttributeSet) retourne possede
     * @return un ensemble contenant uniquement les attributs donnés en argument
     */
    public static AttributeSet of(Attribute... attributes){
        long bits = 0;
        for(Attribute attribute : attributes){
            bits = (long) (bits + Math.pow(2, attribute.ordinal()));
        }
        return (new AttributeSet(bits));
    }

    /**
     * Retourne vrai ssi l'ensemble récepteur (this) contient l'attribut donné
     * @param attribute attribute donnee
     * @return vrai ssi l'ensemble récepteur (this) contient l'attribut donné
     */
    public boolean contains(Attribute attribute){
        return (bits & (1L << attribute.ordinal()))== (1L << attribute.ordinal());
    }

    /**
     * Retourne vrai ssi l'intersection de l'ensemble récepteur (this) avec celui passé en argument (that) n'est pas vid
     * @param that Ensemble en argument par rapport auquel on compare leu intersection
     * @return vrai ssi l'intersection de l'ensemble récepteur (this) avec celui passé en argument (that) n'est pas vid
     */
    public boolean intersects(AttributeSet that){
        return (that.bits & this.bits) != 0;
    }

    /**
     * Retourne une chaîne composée de la représentation textuelle des éléments de l'ensemble entourés d'accolades et séparés par des virgules
     * @return une chaîne composée de la représentation textuelle des éléments de l'ensemble entourés d'accolades et séparés par des virgules
     */
    @Override
    public String toString(){
        StringJoiner j = new StringJoiner("," , "{", "}");
        for(Attribute attribute : Attribute.values()){
            if(contains(attribute)){
               j.add(attribute.keyValue());
            }
        }
        return j.toString();
    }
}
