package ch.epfl.javelo.projection;

import ch.epfl.javelo.Preconditions;

import static java.lang.Math.scalb;

public record PointWebMercator(double x, double y) {
    /**
     * Constructeur compact de l'enregistrement
     * Vérifie si x et y sont dans l'intervalle [0,1] (sinon, lève une IllegalArgumentException)
     */
    public PointWebMercator {
        Preconditions.checkArgument((x >= 0) && (x <= 1) && (y >= 0) && (y <= 1));
    }

    /**
     * Retourne un nouvel objet PointWebMercator en transformant ses coordonnées selon le niveau de zoom
     * @param zoomLevel (niveau de Zoom)
     * @param x coordonnee x du point
     * @param y coordonnee y du point
     * @return un objet PointWebMercator dont les coordonnées sont représentées par v et y
     */
    public static PointWebMercator of(int zoomLevel, double x, double y) {
        double v = scalb(x, -(zoomLevel+8));
        double w = scalb(y, -(zoomLevel+8));
        return new PointWebMercator(v, w);
    }

    /**
     * Retourne un nouvel objet PointWebMercator en transformant des coordonnées à partir d'un objet PointCh
     * @param pointCh (objet PointCh en coordonées suisses)
     * @return un objet PointWebMercator dont les coordonnées sont transformées à partir des cordonnées de pointCh
     */
    public static PointWebMercator ofPointCh(PointCh pointCh){
        return (new PointWebMercator(WebMercator.x(pointCh.lon()), WebMercator.y(pointCh.lat())));
    }
    /**
     * Donne la transformation de la coordonnée x selon le niveau de zoom
     * @param zoomLevel (niveau de zoom)
     * @return une nouvelle coordonnée de type double à partir de x adaptée au niveau de zoom
     */
    public double xAtZoomLevel(int zoomLevel){
       return scalb(x, zoomLevel+8) ;
    }

    /**
     * Donne la transformation de la coordonnée y selon le niveau de zoom
     * @param zoomLevel (niveau de zoom)
     * @return une nouvelle coordonnée de type double à partir de y adaptée au niveau de zoom
     */
    public double yAtZoomLevel(int zoomLevel){
        return scalb(y, zoomLevel+8);
    }

    /**
     * Donne la longitude d'un point en fonction de ses coordonnées WebMercator
     * @return la longtiude lon du point
     */
    public double lon() {
      return WebMercator.lon(x);
    }

    /**
     * Donne la latitude d'un point en fonction de ses coordonnées WebMercator
     * @return la latitude lat du point
     */
    public double lat() {
        return WebMercator.lat(y);
    }

    /**
     * Donne la transformation de PointWebMercator en PointCh (coordonnées suisses)
     * @return un objet PointCh transformé à partir de l'enregistrement PointWebMercator
     */
    public PointCh toPointCh(){
        return new PointCh(Ch1903.e(lon(), lat()), Ch1903.n(lon(), lat()));
    }
}
