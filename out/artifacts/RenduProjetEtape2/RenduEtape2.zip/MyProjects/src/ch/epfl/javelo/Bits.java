package ch.epfl.javelo;

public final class Bits {
    private Bits(){}

    /**
     * Retourne l'entier dont le vectuer de 32 bits est extrait du vecteur de 32 bits value la plage de length bits commençant au bit d'index start, qu'elle interprète comme une valeur signée en complément à deux
     * @param value entier initial
     * @param start index du du bit initial
     * @param length taille de l'extraction qu'on veut
     * @return l'entier dont le vectuer de 32 bits est extrait du vecteur de 32 bits value la plage de length bits commençant au bit d'index start, qu'elle interprète comme une valeur signée en complément à deux
     */
    public static int extractSigned(int value, int start, int length){
        Preconditions.checkArgument(start+length<=32);
        return (value << 32-(start+length))>>(32-length);
    }

    /**
     *Retourne l'entier dont le vectuer de 32 bits est extrait du vecteur de 32 bits value la plage de length bits commençant au bit d'index start, qu'elle interprète comme une valeur non-signée
     * @param value entier initial
     * @param start index du du bit initial
     * @param length taille de l'extraction qu'on veut
     * @return l'entier dont le vectuer de 32 bits est extrait du vecteur de 32 bits value la plage de length bits commençant au bit d'index start, qu'elle interprète comme une valeur non-signée
     */
    public static int extractUnsigned(int value, int start, int length){
        Preconditions.checkArgument((start+length<=32)&& (length!=32));
        return Byte.toUnsignedInt((byte) ((value << 32-(start+length))>>>(32-length)));
    }
}
