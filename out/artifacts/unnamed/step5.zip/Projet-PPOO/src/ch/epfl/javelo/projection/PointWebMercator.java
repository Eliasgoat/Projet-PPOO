package ch.epfl.javelo.projection;

import ch.epfl.javelo.Preconditions;

import static java.lang.Math.scalb;

public record PointWebMercator(double x, double y) {
    public PointWebMercator {
        Preconditions.checkArgument((x >= 0) && (x <= 1) && (y <= 1) && (y >= 0));
    }
    /**
     * @param zoomLevel niveau de zoom
     * @param x coordonnee x du point
     * @param y coordonnee y du point
     * @return le pointCh dont les coordonnées sont x et y au niveau de zoom zoomLevel
     */
    public static PointWebMercator of(int zoomLevel, double x, double y) {
        return new PointWebMercator(scalb(x, -(zoomLevel+8)), scalb(y, -(zoomLevel+8)));
    }

    /**
     * @param pointCh objet PointCh en coordonees suisses
     * @return un objet PointWebMercator dont les coordonnees sont transformées à partir des cordonnees de pointCh
     */
    public static PointWebMercator ofPointCh(PointCh pointCh){
        double x = WebMercator.x(pointCh.lon());
        double y = WebMercator.y(pointCh.lat());
        return (new PointWebMercator(x,y));
    }

    /**
     * @param zoomLevel niveau de zoom
     * @return une nouvelle coordonnee de type double à partir de y adaptee au niveau de zoom
     */
    public double yAtZoomLevel(int zoomLevel){
        return scalb(y, zoomLevel+8);
    }

    /**
     * @param zoomLevel niveau de zoom
     * @return une nouvelle coordonnee de type double à partir de x adaptee au niveau de zoom
     */
    public double xAtZoomLevel(int zoomLevel){
       return scalb(x, zoomLevel+8) ;
    }

    /**
     * @return la latitude lat du point, en radians
     */
    public double lat() {
        return WebMercator.lat(y);
    }

    /**
     * @return la longtiude lon du point, en radians
     */
    public double lon() {
        return WebMercator.lon(x);
    }

    /**
     * @return le point de coordonnées suisses se trouvant à la même position que le récepteur (this)
     * ou null si ce point n'est pas dans les limites de la Suisse définies par SwissBounds
     */
    public PointCh toPointCh(){
        double e = Ch1903.e(lon(), lat());
        double n = Ch1903.n(lon(), lat());
        return new PointCh(e,n);
    }
}
