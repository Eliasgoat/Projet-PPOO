package ch.epfl.javelo.data;

import ch.epfl.javelo.Bits;
import ch.epfl.javelo.Math2;
import ch.epfl.javelo.Preconditions;
import ch.epfl.javelo.Q28_4;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;

public record GraphEdges(ByteBuffer edgesBuffer, IntBuffer profileIds, ShortBuffer elevations) {

    /**
     * Retourne vrai ssi l'arête d'identité donnée va dans le sens inverse de la voie OSM dont elle provient
     *
     * @param edgeId identité de l'arête
     * @return vrai ssi l'arête d'identité donnée va dans le sens inverse de la voie OSM dont elle provient
     */
    public boolean isInverted(int edgeId) {
        Preconditions.checkArgument(edgeId >= 0);
        return ((edgesBuffer.getInt(10 * edgeId)) < 0);
    }

    /**
     * Retourne l'identité du nœud destination de l'arête d'identité donnée
     *
     * @param edgeId identité de l'arête
     * @return l'identité du nœud destination de l'arête d'identité donnée
     */
    public int targetNodeId(int edgeId) {
        Preconditions.checkArgument(edgeId >= 0);
        if (this.isInverted(edgeId)) {
            return ~(edgesBuffer.getInt(10 * edgeId));
        } else return (edgesBuffer.getInt(10 * edgeId));
    }

    /**
     * Retourne la longueur, en mètres, de l'arête d'identité donnée
     *
     * @param edgeId identité de l'arête
     * @return la longueur, en mètres, de l'arête d'identité donnée
     */
    public double length(int edgeId) {
        Preconditions.checkArgument(edgeId >= 0);
        return Q28_4.asDouble(Short.toUnsignedInt(edgesBuffer.getShort(10 * edgeId + 4)));
    }

    /**
     * Retourne le dénivelé positif, en mètres, de l'arête d'identité donnée
     *
     * @param edgeId identité de l'arête
     * @return le dénivelé positif, en mètres, de l'arête d'identité donnée
     */
    public double elevationGain(int edgeId) {
        Preconditions.checkArgument(edgeId >= 0);
        return Q28_4.asDouble(Short.toUnsignedInt(edgesBuffer.getShort(10 * edgeId + 6)));
    }

    /**
     * Retourne vrai ssi l'arête d'identité donnée possède un profil
     *
     * @param edgeId identité de l'arête
     * @return vrai ssi l'arête d'identité donnée possède un profil
     */
    public boolean hasProfile(int edgeId) {
        Preconditions.checkArgument(edgeId >= 0);
        return ((profileIds.get(edgeId) >>> 30) != 0);
    }

    /**
     * Retourne le tableau des échantillons du profil de l'arête d'identité donnée, qui est vide si l'arête ne possède pas de profil,
     *
     * @param edgeId identité de l'arête
     * @return le tableau des échantillons du profil de l'arête d'identité donnée, qui est vide si l'arête ne possède pas de profil,
     */
    public float[] profileSamples(int edgeId) {
        Preconditions.checkArgument(edgeId >= 0);
        float[] array = new float[0];
        int startIndex = Bits.extractUnsigned(profileIds.get(edgeId), 0, 30);
        int numberOfSamples = 1 + Math2.ceilDiv(edgesBuffer.getShort(10 * edgeId + 4), Q28_4.ofInt(2));
        switch (profileIds.get(edgeId) >>> 30) {
            case 0:
                array = new float[0];
                break;
            case 1:
                array = new float[numberOfSamples];
                for (int i = 0; i < numberOfSamples; i++) {
                    array[i] = Q28_4.asFloat(Short.toUnsignedInt(elevations.get(startIndex + i)));
                }
                break;
            case 2:
                array = new float[numberOfSamples];
                for (int i = 0; i < numberOfSamples; i++) {
                    if (i == 0) {
                        array[0] = Q28_4.asFloat(Short.toUnsignedInt(elevations.get(startIndex)));
                    } else {
                        float extractedValue;
                        if (i % 2 == 0) {
                            extractedValue = Q28_4.asFloat(Bits.extractSigned(elevations.get(Math2.ceilDiv(i, 2) + startIndex), 0, 8));
                        } else {
                            extractedValue = Q28_4.asFloat(Bits.extractSigned(elevations.get(Math2.ceilDiv(i, 2) + startIndex), 8, 8));
                        }
                        array[i] = array[i - 1] + extractedValue;
                    }
                }
                break;
            case 3:
                array = new float[numberOfSamples];
                for (int i = 0; i < numberOfSamples; i++) {
                    if (i == 0) {
                        array[0] = Q28_4.asFloat(Short.toUnsignedInt(elevations.get(startIndex)));
                    } else {
                        float extractedValue;
                        if (i % 4 == 0) {
                            extractedValue = Q28_4.asFloat(Bits.extractSigned(elevations.get(Math2.ceilDiv(i, 4) + startIndex), 0, 4));
                        } else if (i % 4 == 1) {
                            extractedValue = Q28_4.asFloat(Bits.extractSigned(elevations.get(Math2.ceilDiv(i, 4) + startIndex), 12, 4));
                        } else if (i % 4 == 2) {
                            extractedValue = Q28_4.asFloat(Bits.extractSigned(elevations.get(Math2.ceilDiv(i, 4) + startIndex), 8, 4));
                        } else {
                            extractedValue = Q28_4.asFloat(Bits.extractSigned(elevations.get(Math2.ceilDiv(i, 4) + startIndex), 4, 4));
                        }
                        array[i] = array[i - 1] + extractedValue;
                    }
                }
                break;
        }
        if (array.length == 0) {
            return array;
        } else if (this.isInverted(edgeId)) {
            for (int i = 0; i < array.length / 2; i++) {
                Object array1 = array[i];
                array[i] = array[array.length - 1 - i];
                array[array.length - 1 - i] = (float) array1;
            }
            return array;
        } else {
            return array;
        }
    }

    /**
     * Retourne l'identité de l'ensemble d'attributs attaché à l'arête d'identité donnée
     * @param edgeId identité de l'arête
     * @return l'identité de l'ensemble d'attributs attaché à l'arête d'identité donnée
     */
    public int attributesIndex(int edgeId) {
        Preconditions.checkArgument(edgeId >= 0);
        return Short.toUnsignedInt(edgesBuffer.getShort(10 * edgeId + 8));
    }
}
