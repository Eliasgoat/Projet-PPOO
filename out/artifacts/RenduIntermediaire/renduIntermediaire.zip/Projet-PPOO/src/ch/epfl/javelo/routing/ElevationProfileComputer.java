package ch.epfl.javelo.routing;

import ch.epfl.javelo.Math2;
import ch.epfl.javelo.Preconditions;

import java.util.Arrays;

/**
 * Un calculateur de profil en long
 *
 * @author Elias Mir(341277)
 */
public final class ElevationProfileComputer {

    private ElevationProfileComputer() {}

    /**
     * Trouve l'echantillon en fonction du profil
     *
     * @param route         itinéraire route,
     * @param maxStepLength maximun pas possible
     * @return le profil en long de l'itinéraire route,
     * en garantissant que l'espacement entre les échantillons du profil est d'au maximum maxStepLength mètres
     * @throws IllegalArgumentException si maxStepLength est negatif
     */
    public static ElevationProfile elevationProfile(Route route, double maxStepLength) {
        Preconditions.checkArgument(maxStepLength > 0);

        int sampleNumber = (int) Math.ceil(route.length() / maxStepLength) + 1;
        float[] samples = new float[sampleNumber];
        double delta = route.length() / (sampleNumber - 1);
        for (int i = 0; i < sampleNumber; i++) {
            samples[i] = (float) route.elevationAt(i * delta);
        }

        //Trouve l'index du premier nombre valide
        int indexFirstNumber = 0;
        while (indexFirstNumber < sampleNumber && Float.isNaN(samples[indexFirstNumber])) {
            indexFirstNumber++;
        }

        //Trouve l'index du dernier nombre valide
        int indexLastNumber = sampleNumber - 1;
        while (indexLastNumber > -1 && Float.isNaN(samples[indexLastNumber])) {
            indexLastNumber--;
        }

        //Traite les cas ou les premiers et derniers nombres sont de la forme NaN
        if (indexLastNumber == -1) {
            Arrays.fill(samples, 0, sampleNumber, 0);
        } else if (indexFirstNumber > 0) {
            Arrays.fill(samples, 0, indexFirstNumber - 1, samples[indexFirstNumber]);
        } else if (indexLastNumber < sampleNumber - 1 && indexLastNumber >= 0) {
            Arrays.fill(samples, indexLastNumber + 1, sampleNumber, samples[indexLastNumber]);
        }

        //Traite les cas ou il y a des NaN dans le tableau d'echantillon
        for (int i = 0; i < sampleNumber; i++) {
            if (Float.isNaN(samples[i])) {
                int intialindex = i - 1;
                int finalIndex = i;
                while (Float.isNaN(samples[finalIndex])) {
                    finalIndex++;
                }
                samples[i] = (float) Math2.interpolate(
                        samples[intialindex], samples[finalIndex],
                        (double) 1 / (finalIndex - intialindex)
                );
            }
        }

        return new ElevationProfile(route.length(), samples);
    }
}
