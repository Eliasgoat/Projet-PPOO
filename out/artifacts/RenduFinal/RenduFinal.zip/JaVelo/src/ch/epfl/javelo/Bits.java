package ch.epfl.javelo;

/**
 * Utility class to handle binary values
 *
 * @author Jan Staszewicz (341201)
 */
public final class Bits {

    //non-instantiable
    private Bits() {
    }

    /**
     * Extracts bits of length "length" from "start" as signed
     *
     * @param value  the value in bits
     * @param start  start index
     * @param length length of wanted bits string
     * @return signed extracted bits string
     */
    public static int extractSigned(int value, int start, int length) {

        Preconditions.checkArgument(!(start + (length - 1) > 31 || start < 0 || length <= 0));

        return (value << 32 - (start + length)) >> 32 - length;
    }

    /**
     * Extracts bits of length "length" from "start" as unsigned
     *
     * @param value  the value in bits
     * @param start  start index
     * @param length length of wanted bits string
     * @return unsigned extracted bits
     */
    public static int extractUnsigned(int value, int start, int length) {
        Preconditions.checkArgument(!(start + (length - 1) > 31 || length == 32 || start < 0 || length <= 0));

        return (value << 32 - (start + length)) >>> 32 - length;
    }
}
