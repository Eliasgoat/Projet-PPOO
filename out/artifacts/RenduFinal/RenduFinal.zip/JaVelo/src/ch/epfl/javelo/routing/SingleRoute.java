package ch.epfl.javelo.routing;

import ch.epfl.javelo.Math2;
import ch.epfl.javelo.Preconditions;
import ch.epfl.javelo.projection.PointCh;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * A route with a single segment
 *
 * @author Jan Staszewicz (341201)
 */
public final class SingleRoute implements Route {

    private final List<Edge> edges;
    private final double totalLength;
    private final List<PointCh> totalPoints;
    private final double[] nodePositionTable;

    /**
     * Constructs new single route
     *
     * @param edges list of route's edges
     */
    public SingleRoute(List<Edge> edges) {

        Preconditions.checkArgument(!edges.isEmpty());

        //create one time all attributes
        this.edges = List.copyOf(edges);
        this.totalPoints = getTotalPoints();
        this.nodePositionTable = getNodeTable();
        this.totalLength = getTotalLength();
    }

    /**
     * Creates list with node positions on the route
     *
     * @return node positions list
     */
    private double[] getNodeTable() {
        double[] l = new double[edges.size() + 1];

        l[0] = 0;

        int i = 1;
        for (Edge edge : edges) {
            l[i] = l[i - 1] + edge.length();
            i++;
        }

        return l;
    }

    /**
     * Gets all points from edges ends
     *
     * @return list containing all points
     */
    private List<PointCh> getTotalPoints() {
        List<PointCh> l = new ArrayList<>();

        l.add(edges.get(0).fromPoint());

        for (Edge edge : edges) {
            l.add(edge.toPoint());
        }

        return l;
    }


    /**
     * Gets total route's length
     *
     * @return total route's length
     */
    private double getTotalLength() {
        return this.nodePositionTable[nodePositionTable.length - 1];
    }

    @Override
    public int indexOfSegmentAt(double position) {
        return 0;
    }

    @Override
    public double length() {
        return this.totalLength;
    }

    @Override
    public List<Edge> edges() {
        return new ArrayList<>(edges);
    }

    @Override
    public List<PointCh> points() {
        return new ArrayList<>(totalPoints);
    }

    /**
     * Get position by binary search
     *
     * @param position the position
     * @return position in position table
     */
    private int getPosByBinarySearch(double position) {
        return Arrays.binarySearch(this.nodePositionTable, position);
    }

    @Override
    public PointCh pointAt(double position) {

        position = Math2.clamp(0, position, length());
        int pos = getPosByBinarySearch(position);
        PointCh point;

        if (pos >= 0) {
            point = totalPoints.get(pos);
        } else {
            int edge_index = (pos + 2) * -1;
            point = edges.get(edge_index).pointAt(position - nodePositionTable[edge_index]);

        }
        return new PointCh(point.e(), point.n());

    }

    @Override
    public double elevationAt(double position) {

        position = Math2.clamp(0, position, length());
        int pos = getPosByBinarySearch(position);

        if (pos >= 0) {
            if (pos == nodePositionTable.length - 1) {
                Edge edge = edges.get(pos - 1);
                return edge.elevationAt(edge.length());
            }
            return edges.get(pos).elevationAt(0);
        } else {
            int edge_index = (pos + 2) * -1;
            return edges.get(edge_index).elevationAt(position - nodePositionTable[edge_index]);
        }
    }

    @Override
    public int nodeClosestTo(double position) {

        position = Math2.clamp(0, position, length());
        int pos = getPosByBinarySearch(position);

        if (pos >= 0) {
            if (pos == nodePositionTable.length - 1) {
                return edges.get(pos - 1).toNodeId();
            } else {
                return edges.get(pos).fromNodeId();
            }
        } else {
            int edge_index = (pos + 2) * -1;
            Edge edge = edges.get(edge_index);
            double l = edge.length();

            if ((position - nodePositionTable[edge_index]) <= l / 2) {
                return edge.fromNodeId();
            } else {
                return edge.toNodeId();
            }
        }
    }

    @Override
    public RoutePoint pointClosestTo(PointCh point) {

        RoutePoint bestRoutePoint = RoutePoint.NONE;
        double l = 0;

        for (Edge edge : edges) {
            double position = Math2.clamp(0, edge.positionClosestTo(point), edge.length());
            PointCh edgePoint = edge.pointAt(position);
            double distanceToEdgePoint = point.distanceTo(edgePoint);

            bestRoutePoint = bestRoutePoint.min(edgePoint, l + position, distanceToEdgePoint);

            l += edge.length();
        }

        return bestRoutePoint;
    }
}
