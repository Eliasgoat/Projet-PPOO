package ch.epfl.javelo.data;

import ch.epfl.javelo.Bits;
import ch.epfl.javelo.Math2;
import ch.epfl.javelo.Q28_4;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.util.Arrays;
import java.util.Collections;

/**
 * Edges of javelo graph
 *
 * @author Jan Staszewicz (341201)
 */
public record GraphEdges(ByteBuffer edgesBuffer, IntBuffer profileIds, ShortBuffer elevations) {

    public static final int OFFSET_LENGTH = Integer.BYTES;
    public static final int OFFSET_HEIGHT = OFFSET_LENGTH + Short.BYTES;
    public static final int OFFSET_EDGE = 10;


    /**
     * Check if edge is inverted
     *
     * @param edgeId the edge id
     * @return true if edge is inverted, false otherwise
     */
    public boolean isInverted(int edgeId) {

        int infoInt = edgesBuffer.getInt(edgeId * OFFSET_EDGE);

        return infoInt < 0;
    }

    /**
     * Return id of target node form given edge
     *
     * @param edgeId the edge id
     * @return id of target node
     */
    public int targetNodeId(int edgeId) {

        int infoInt = edgesBuffer.getInt(edgeId * OFFSET_EDGE);

        if (isInverted(edgeId)) {
            return ~infoInt;
        } else {
            return Bits.extractUnsigned(infoInt, 0, 31);
        }

    }


    /**
     * Gets bits representing the length of given edge
     *
     * @param edgeId the edge id
     * @return edge length in Q28_4
     */
    public int getLengthInt(int edgeId) {
        return Short.toUnsignedInt(edgesBuffer.getShort(edgeId * OFFSET_EDGE + OFFSET_LENGTH));
    }

    /**
     * Gets length of given edge by id
     *
     * @param edgeId the edge id
     * @return length of given edge
     */
    public double length(int edgeId) {
        return Q28_4.asDouble(getLengthInt(edgeId));
    }

    /**
     * Gets elevation gain of given edge
     *
     * @param edgeId the edge id
     * @return elevation gain of given edge
     */
    public double elevationGain(int edgeId) {
        int infoInt = Short.toUnsignedInt(edgesBuffer.getShort(edgeId * OFFSET_EDGE + OFFSET_HEIGHT));

        return Q28_4.asDouble(infoInt);
    }

    /**
     * Checks if edge has profile
     *
     * @param edgeId the edge id
     * @return true if edge has a profile, false otherwise
     */
    public boolean hasProfile(int edgeId) {
        return Bits.extractUnsigned(profileIds.get(edgeId), 30, 2) != 0;
    }


    /**
     * Computes number of samples in edge profile given his length
     *
     * @param length of edge
     * @return number of samples
     */
    private int numberOfSamples(int length) {
        return 1 + Math2.ceilDiv(length, Q28_4.ofInt(2));
    }

    /**
     * Reverse content of array
     *
     * @param table a float array
     * @return reversed array
     */
    private float[] reverseTable(float[] table) {
        float[] newTable = new float[table.length];

        for (int i = table.length - 1; i >= 0; i--) {
            newTable[table.length - 1 - i] = table[i];
        }

        return newTable;
    }

    /**
     * Gets all profile samples of edge by index
     *
     * @param edgeId the edge id
     * @return array of all profile samples
     */
    public float[] profileSamples(int edgeId) {

        if (!hasProfile(edgeId)) {
            return new float[0];
        }

        //Init variables for the algorithm
        int firstSampleId = Bits.extractUnsigned(profileIds.get(edgeId), 0, 30);
        int profile = Bits.extractUnsigned(profileIds.get(edgeId), 30, 2);
        int profileCompressionBits = (int) Math.scalb(16, -(profile - 1)); // 16 if not compressed, 8 if Q4.4, 4 if Q0.4, used for loop later
        int n_samples = numberOfSamples(getLengthInt(edgeId));

        float[] table = new float[n_samples];

        //first value that will be added to next one for compressed elevations
        float predValue = Q28_4.asFloat(Bits.extractUnsigned(elevations.get(firstSampleId), 0, 16));
        table[0] = predValue;

        //number of iteration over buffer for first loop depending on compression
        int iter = (int) Math.ceil((n_samples - 1) * profileCompressionBits / 16.0);

        int counter = 1;

        //Iteration over buffer
        for (int i = 1; i <= iter; i++) {
            for (int j = 0; j < 16 / profileCompressionBits; j++) { //Iteration on each short depending on compression

                float value;

                if (counter < n_samples) {
                    if (profile == 1) { //if no compression, just add each value to each index

                        value = Q28_4.asFloat(Bits.extractUnsigned(elevations.get(firstSampleId + i),
                                16 - (j + 1) * profileCompressionBits, profileCompressionBits));

                        table[counter] = value;

                    } else { //if compressed add value to pred value and add to array

                        value = Q28_4.asFloat(Bits.extractSigned(elevations.get(firstSampleId + i),
                                16 - (j + 1) * profileCompressionBits, profileCompressionBits));

                        predValue = predValue + value;
                        table[counter] = predValue;
                    }
                }

                counter++;
            }
        }

        //INVERT TABLE IF isInverted()
        if (isInverted(edgeId)) {
            table = reverseTable(table);
        }

        return table;
    }

    /**
     * Gets index of attributes value
     *
     * @param edgeId the edge id
     * @return attributes index
     */
    public int attributesIndex(int edgeId) {
        short infoShort = edgesBuffer.getShort(edgeId * OFFSET_EDGE + 8);

        return Short.toUnsignedInt(infoShort);
    }
}

