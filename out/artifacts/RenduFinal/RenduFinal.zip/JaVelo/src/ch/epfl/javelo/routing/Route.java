package ch.epfl.javelo.routing;

import ch.epfl.javelo.projection.PointCh;

import java.util.List;

/**
 * Route of javelo
 *
 * @author Jan Staszewicz (341201)
 */
public interface Route {

    /**
     * Gets segment index at given position
     *
     * @param position the position
     * @return index of segment at given position
     */
    int indexOfSegmentAt(double position);

    /**
     * Gets itinerary length
     *
     * @return itinerary length
     */
    double length();

    /**
     * Gets list of all edges on itinerary
     *
     * @return List of Edge
     */
    List<Edge> edges();

    /**
     * Gets all points on edge endpoints
     *
     * @return list of all edge endpoints on the route
     */
    List<PointCh> points();

    /**
     * Gets point on itinerary with given position
     *
     * @param position the position
     * @return point on itinerary at given position
     */
    PointCh pointAt(double position);

    /**
     * Gets elevation at given position
     *
     * @param position the position
     * @return elevation at given position
     */
    double elevationAt(double position);

    /**
     * Gets node id on itinerary closest to given position
     *
     * @param position the position
     * @return node id of the closest node to given position
     */
    int nodeClosestTo(double position);

    /**
     * Gets point on itinerary closest to given point
     *
     * @param point the point
     * @return route point closest to given point
     */
    RoutePoint pointClosestTo(PointCh point);


}
