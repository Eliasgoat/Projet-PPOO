package ch.epfl.javelo.projection;

import ch.epfl.javelo.Math2;

/**
 * Conversion class for WebMercator system
 *
 * @author Jan Staszewicz (341201)
 */
public final class WebMercator {

    //non-instantiable
    private WebMercator() {
    }

    /**
     * Converts WGS 84 longitude to Web Mercator x coordinate
     *
     * @param lon the longitude
     * @return x coordinate
     */
    public static double x(double lon) {
        return ((lon + Math.PI) / (2.0 * Math.PI));
    }

    /**
     * Converts WGS 84 latitude to Web Mercator y coordinate
     *
     * @param lat the latitude
     * @return y coordinate
     */
    public static double y(double lat) {
        return ((Math.PI - Math2.asinh(Math.tan(lat))) / (2.0 * Math.PI));
    }

    /**
     * Converts Web Mercator x coordinate to WGS 84 longitude
     *
     * @param x coordinate
     * @return longitude
     */
    public static double lon(double x) {
        return 2 * Math.PI * x - Math.PI;
    }

    /**
     * Converts Web Mercator y coordinate to WGS 84 latitude
     *
     * @param y coordinate
     * @return latitude
     */
    public static double lat(double y) {
        return Math.atan(Math.sinh(Math.PI - 2 * Math.PI * y));
    }
}
