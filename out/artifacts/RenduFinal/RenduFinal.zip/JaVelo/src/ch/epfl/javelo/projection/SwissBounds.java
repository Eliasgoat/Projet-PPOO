package ch.epfl.javelo.projection;

/**
 * Swiss bounds
 *
 * @author Jan Staszewicz (341201)
 */
public final class SwissBounds {

    //Constants
    public static final double MIN_E = 2485000.0;
    public static final double MAX_E = 2834000.0;
    public static final double MIN_N = 1075000.0;
    public static final double MAX_N = 1296000.0;
    public static final double WIDTH = MAX_E - MIN_E;
    public static final double HEIGHT = MAX_N - MIN_N;

    //non-instantiable
    private SwissBounds() {
    }

    /**
     * Checks if coordinates are in Swiss limits
     *
     * @param e coordinate
     * @param n coordinate
     * @return boolean, true if is in limit
     */
    public static boolean containsEN(double e, double n) {
        return (MIN_E <= e) && (e <= MAX_E) && (MIN_N < n) && (n < MAX_N);
    }
}
