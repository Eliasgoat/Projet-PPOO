package ch.epfl.javelo.routing;

import ch.epfl.javelo.Math2;
import ch.epfl.javelo.data.Graph;
import ch.epfl.javelo.projection.PointCh;

import java.util.function.DoubleUnaryOperator;

/**
 * Edge data structure
 *
 * @author Jan Staszewicz (341201)
 */
public record Edge(int fromNodeId, int toNodeId, PointCh fromPoint, PointCh toPoint, double length,
                   DoubleUnaryOperator profile) {

    /**
     * Creates an Edge instance
     *
     * @param graph      the javelo graph
     * @param edgeId     the edge id
     * @param fromNodeId starting node id
     * @param toNodeId   ending node id
     * @return new edge
     */
    public static Edge of(Graph graph, int edgeId, int fromNodeId, int toNodeId) {
        PointCh n_fromPoint = graph.nodePoint(fromNodeId);
        PointCh n_toPoint = graph.nodePoint(toNodeId);
        double n_length = graph.edgeLength(edgeId);
        DoubleUnaryOperator profiles_function = graph.edgeProfile(edgeId);

        return new Edge(fromNodeId, toNodeId, n_fromPoint, n_toPoint, n_length, profiles_function);
    }

    /**
     * Gets position on edge in meters closest to given point
     *
     * @param point the point
     * @return closest position
     */
    public double positionClosestTo(PointCh point) {
        return Math2.projectionLength(fromPoint.e(), fromPoint.n(), toPoint.e(), toPoint.n(), point.e(), point.n());
    }

    /**
     * Computes point at given position on the edge
     *
     * @param position the position
     * @return point at given position
     */
    public PointCh pointAt(double position) {

        if(this.length == 0){
            return fromPoint;
        }

        double new_e = (((toPoint.e() - fromPoint.e()) * position) / length) + fromPoint.e();
        double new_n = (((toPoint.n() - fromPoint.n()) * position) / length) + fromPoint.n();

        return new PointCh(new_e, new_n);
    }

    /**
     * Gets elevation at given position
     *
     * @param position the position
     * @return elevation given position
     */
    public double elevationAt(double position) {
        return profile.applyAsDouble(position);
    }

}
