package ch.epfl.javelo.routing;

import ch.epfl.javelo.Functions;
import ch.epfl.javelo.Math2;
import ch.epfl.javelo.Preconditions;

import java.util.DoubleSummaryStatistics;
import java.util.function.DoubleUnaryOperator;

/**
 * Edge elevation profile
 *
 * @author Jan Staszewicz (341201)
 */
public final class ElevationProfile {

    private final double length;
    private final float[] elevationSamples;
    private final DoubleUnaryOperator profile_function;
    private final double minElevation;
    private final double maxElevation;

    /**
     * Constructs an elevation profile
     *
     * @param length           profile length
     * @param elevationSamples elevation samples array
     */
    public ElevationProfile(double length, float[] elevationSamples) {

        Preconditions.checkArgument(!(length <= 0 || elevationSamples.length < 2));

        this.length = length;
        this.elevationSamples = elevationSamples;
        this.profile_function = Functions.sampled(elevationSamples, length);

        DoubleSummaryStatistics s = new DoubleSummaryStatistics();

        for (float value : elevationSamples) {
            s.accept(value);
        }

        this.maxElevation = s.getMax();
        this.minElevation = s.getMin();
    }

    /**
     * Gets profile's length in meters
     *
     * @return profile's length
     */
    public double length() {
        return this.length;
    }

    /**
     * Gets minimum profile's elevation
     *
     * @return minimum elevation
     */
    public double minElevation() {
        return this.minElevation;
    }

    /**
     * Gets maximum profile's elevation
     *
     * @return maximum elevation
     */
    public double maxElevation() {
        return this.maxElevation;
    }

    /**
     * Gets total profile's ascent in meters
     *
     * @return profile's ascent
     */
    public double totalAscent() {
        double totalAscent = 0;

        float predValue = elevationSamples[0];

        for (int i = 1; i < elevationSamples.length; i++) {
            if (elevationSamples[i] > predValue) {
                totalAscent += Math.abs(elevationSamples[i] - predValue);
            }

            predValue = elevationSamples[i];
        }

        return totalAscent;

    }

    /**
     * Gets total profile's descent in meters
     *
     * @return profile's descent
     */
    public double totalDescent() {
        double totalDescent = 0;

        float predValue = elevationSamples[0];

        for (int i = 1; i < elevationSamples.length; i++) {
            if (elevationSamples[i] < predValue) {
                totalDescent += Math.abs(elevationSamples[i] - predValue);
            }

            predValue = elevationSamples[i];
        }

        return totalDescent;
    }

    /**
     * Gets elevation at given position
     *
     * @param position
     * @return elevation at given point
     */
    public double elevationAt(double position) {
        return this.profile_function.applyAsDouble(position);
    }
}
