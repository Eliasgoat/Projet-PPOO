package ch.epfl.javelo.routing;

import ch.epfl.javelo.Math2;
import ch.epfl.javelo.Preconditions;
import ch.epfl.javelo.projection.PointCh;

import java.util.ArrayList;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;


/**
 * Groups of routes
 *
 * @author Jan Staszewicz (341201)
 */
public final class MultiRoute implements Route {

    private final double totalLength;
    private final double[] positionTable;
    private final List<Route> segments;
    private final List<Edge> edges;
    private final List<PointCh> points;

    /**
     * Construcs new multi-route
     *
     * @param segments the route segments
     */
    public MultiRoute(List<Route> segments) {
        Preconditions.checkArgument(!segments.isEmpty());

        //create attributes
        this.segments = List.copyOf(segments);
        this.totalLength = getTotalLength();
        this.edges = getEdges();
        this.points = getAllPoints();
        this.positionTable = getSegmentsPositionTable();
    }

    /**
     * Creates table containing position of segments extremities
     *
     * @return segment position table
     */
    private double[] getSegmentsPositionTable() {
        double[] l = new double[segments.size() + 1];

        l[0] = 0;

        int i = 1;
        for (Route route : segments) {
            l[i] = l[i - 1] + route.length();
            i++;
        }

        return l;
    }

    /**
     * Creates table containing all points
     *
     * @return table containing all points
     */
    private List<PointCh> getAllPoints() {

        List<PointCh> pl = new ArrayList<>();

        int counter = 0;

        for (Route segment : segments) {
            List<PointCh> s_pointsList = segment.points();
            int l = s_pointsList.size();

            if (counter == segments.size() - 1 && (pl.isEmpty() || s_pointsList.get(l - 1) != pl.get(0))) { //if last point is not equal to first one
                pl.addAll(s_pointsList);
            } else {
                s_pointsList.remove(s_pointsList.size() - 1);
                pl.addAll(s_pointsList);
            }

            counter++;
        }

        return pl;
    }

    /**
     * Creates list containing all edges
     *
     * @return list containing all edges
     */
    private List<Edge> getEdges() {
        List<Edge> all_edges = new ArrayList<>();

        for (Route route : segments) {
            all_edges.addAll(route.edges());
        }

        return all_edges;
    }

    /**
     * Computes total route's length
     *
     * @return total route's length
     */
    private double getTotalLength() {
        double l = 0;

        for (Route route : segments) {
            l += route.length();
        }

        return l;
    }

    @Override
    public int indexOfSegmentAt(double position) {


        position = Math2.clamp(0, position, positionTable[positionTable.length - 1]);

        int index = 0;
        double l = 0;

        for (Route route : segments) {
            double sl = route.length();
            l += sl;

            if (position <= l) {
                index += route.indexOfSegmentAt(sl - (l - position));
                break;
            } else {
                index += route.indexOfSegmentAt(sl - (l - position)) + 1;
            }
        }

        return index;
    }

    @Override
    public double length() {
        return this.totalLength;
    }

    @Override
    public List<Edge> edges() {
        return new ArrayList<>(this.edges);
    }

    @Override
    public List<PointCh> points() {
        return new ArrayList<>(points);
    }

    /**
     * Get position by binary search
     *
     * @param position the position on the route
     * @return position in the position table
     */
    private int getPosByBinarySearch(double position) {
        position = Math2.clamp(0, position, length());
        return Arrays.binarySearch(this.positionTable, position);
    }

    @Override
    public PointCh pointAt(double position) {

        int pos = getPosByBinarySearch(position);

        if (pos >= 0) {
            if (pos == segments.size()) {
                return edges.get(edges.size() - 1).toPoint();
            }
            return segments.get(pos).pointAt(position - positionTable[pos]);
        } else {
            int segment_index = (pos + 2) * -1;
            return segments.get(segment_index).pointAt(position - positionTable[segment_index]);
        }
    }

    @Override
    public double elevationAt(double position) {
        int pos = getPosByBinarySearch(position);

        if (pos >= 0) {
            if (pos == segments.size()) {
                return segments.get(pos - 1).elevationAt(position - positionTable[pos]);
            }
            return segments.get(pos).elevationAt(position - positionTable[pos]);
        } else {
            int segment_index = (pos + 2) * -1;
            return segments.get(segment_index).elevationAt(position - positionTable[segment_index]);
        }
    }

    @Override
    public int nodeClosestTo(double position) {
        int pos = getPosByBinarySearch(position);

        if (pos >= 0) {
            if (pos == segments.size()) {
                return edges.get(edges.size() - 1).toNodeId();
            }
            return segments.get(pos).nodeClosestTo(position - positionTable[pos]);
        } else {
            int segment_index = (pos + 2) * -1;
            return segments.get(segment_index).nodeClosestTo(position - positionTable[segment_index]);
        }
    }

    @Override
    public RoutePoint pointClosestTo(PointCh point) {

        RoutePoint bestRoutePoint = RoutePoint.NONE;
        double l = 0;

        for (Route route : segments) {
            bestRoutePoint = bestRoutePoint.min(route.pointClosestTo(point).withPositionShiftedBy(l));
            l += route.length();
        }

        return bestRoutePoint;
    }
}
