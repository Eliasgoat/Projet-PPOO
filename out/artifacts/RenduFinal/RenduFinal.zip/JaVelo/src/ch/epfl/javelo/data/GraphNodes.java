package ch.epfl.javelo.data;

import ch.epfl.javelo.Bits;
import ch.epfl.javelo.Q28_4;

import java.nio.IntBuffer;

/**
 * Graph nodes of javelo
 *
 * @author Jan Staszewicz (341201)
 */
public record GraphNodes(IntBuffer buffer) {

    //CONSTANTS
    private static final int OFFSET_E = 0;
    private static final int OFFSET_N = 1;
    private static final int OFFSET_OUT_EDGES = 2;
    private static final int NODE_INTS = 3;

    /**
     * Gets total number of nodes
     *
     * @return total number of nodes
     */
    public int count() {
        return buffer.capacity() / 3;
    }

    /**
     * Gets E coordinate from node of id nodeId
     *
     * @param nodeId the node id
     * @return E coordinates of given node
     */
    public double nodeE(int nodeId) {
        return Q28_4.asDouble(buffer.get(NODE_INTS * nodeId + OFFSET_E));
    }

    /**
     * Gets N coordinate from node of id nodeId
     *
     * @param nodeId the node id
     * @return N coordinates of given node
     */
    public double nodeN(int nodeId) {
        return Q28_4.asDouble(buffer.get(NODE_INTS * nodeId + OFFSET_N));
    }

    /**
     * Gets number of outgoing edges from given node
     *
     * @param nodeId the node id
     * @return number of outgoing edges of given node
     */
    public int outDegree(int nodeId) {
        int x = buffer.get(NODE_INTS * nodeId + OFFSET_OUT_EDGES);
        return Bits.extractUnsigned(x, 28, 4);
    }

    /**
     * Gets id of the edge by it's index from all outgoing edges
     *
     * @param nodeId    the node id
     * @param edgeIndex the edge index from outgoing edges
     * @return the edge id
     */
    public int edgeId(int nodeId, int edgeIndex) {

        assert 0 <= edgeIndex && edgeIndex < outDegree(nodeId);

        int x = buffer.get(NODE_INTS * nodeId + OFFSET_OUT_EDGES);
        return Bits.extractUnsigned(x, 0, 28) + edgeIndex;
    }

}
