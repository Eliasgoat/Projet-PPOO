package ch.epfl.javelo.data;

import ch.epfl.javelo.Preconditions;

import java.util.StringJoiner;

/**
 * Set of OMS attributes
 *
 * @author Jan Staszewicz (341201)
 */
public record AttributeSet(long bits) {

    /**
     * Construct an attribute set
     *
     * @param bits of new attribute set
     */
    public AttributeSet {
        Preconditions.checkArgument((bits >>> 62) == 0b00);
    }

    /**
     * Creates a set of attributes
     *
     * @param attributes Arbitrary Number of Arguments of attributes
     * @return set of attributes
     */
    public static AttributeSet of(Attribute... attributes) {
        long bits = 0;

        for (Attribute attribute : attributes) {
            int index = attribute.ordinal();
            bits = bits | (1L << index); //change the bit at index "index" to 1
        }

        return new AttributeSet(bits);
    }

    /**
     * Checks if given attribute is in the AttributeSet
     *
     * @param attribute the attribute
     * @return true if contains the attribute, false otherwise
     */
    public boolean contains(Attribute attribute) {
        return this.bits() == (this.bits | (1L << attribute.ordinal()));
    }

    /**
     * Checks if intersection of two AttributeSets is non-empty
     *
     * @param that the other attribute set
     * @return true if intersection is non-empty, false otherwise
     */
    public boolean intersects(AttributeSet that) {
        return (this.bits & that.bits()) != 0;
    }

    /**
     * Creates a string describing attributes of the set
     *
     * @return String of attributes
     */
    @Override
    public String toString() {
        StringJoiner joiner = new StringJoiner(",", "{", "}");

        for (Attribute attribute : Attribute.ALL) {
            if (this.contains(attribute)) {
                joiner.add(attribute.key() + "=" + attribute.value());
            }
        }

        return joiner.toString();
    }
}
