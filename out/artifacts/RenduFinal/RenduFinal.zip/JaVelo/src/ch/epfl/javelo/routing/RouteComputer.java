package ch.epfl.javelo.routing;

import ch.epfl.javelo.Bits;
import ch.epfl.javelo.Preconditions;
import ch.epfl.javelo.data.Graph;
import ch.epfl.javelo.projection.PointCh;

import java.util.*;

/**
 * Route computer, creating routes between two points
 *
 * @author Jan Staszewicz
 */
public final class RouteComputer {

    private final Graph graph;
    private final CostFunction costFunction;

    /**
     * Constructs a RouteComputer
     *
     * @param graph        the javelo graph
     * @param costFunction the cost function
     */
    public RouteComputer(Graph graph, CostFunction costFunction) {
        this.graph = graph;
        this.costFunction = costFunction;
    }

    /**
     * Builds route using the array of linked nodes by predecessors
     *
     * @return the built route
     */
    private Route buildRoute(int[] predecessors, int startNode, int endNodeId) {

        List<Edge> edges = new ArrayList<>();
        int predNode;
        int edgeIndex;

        int currentNode = endNodeId;

        while (currentNode != startNode) {
            //extract from predecessors table
            predNode = Bits.extractUnsigned(predecessors[currentNode], 0, 28);
            edgeIndex = Bits.extractUnsigned(predecessors[currentNode], 28, 4);
            Edge new_edge = Edge.of(graph, graph.nodeOutEdgeId(predNode, edgeIndex), predNode, currentNode);
            edges.add(new_edge);

            currentNode = predNode;
        }

        Collections.reverse(edges);

        return new SingleRoute(edges);
    }

    /**
     * Get distance to end Point.
     *
     * @param fp from point
     * @param tp the endpoint
     * @return distance to endpoint
     */
    private double getDistanceToEnd(PointCh fp, PointCh tp) {
        return fp.distanceTo(tp);
    }

    /**
     * Computes itinerary with the smallest cost form startNodeId to endNodeId.
     *
     * @param startNodeId the starting node id
     * @param endNodeId   the ending node id
     * @return best route between the two given nodes
     */
    public Route bestRouteBetween(int startNodeId, int endNodeId) {

        /**
         * A node parametrized with distance
         */
        record WeightedNode(int nodeId, float distance)
                implements Comparable<WeightedNode> {
            @Override
            public int compareTo(WeightedNode that) {
                return Float.compare(this.distance, that.distance);
            }
        }

        //preconditions
        Preconditions.checkArgument(startNodeId >= 0 && endNodeId >= 0);

        int node_n = graph.nodeCount();

        //create tables
        float[] distance = new float[graph.nodeCount()];
        int[] predecessors = new int[node_n];

        //fill table
        Arrays.fill(distance, Float.POSITIVE_INFINITY);

        PointCh toPoint = graph.nodePoint(endNodeId); //endpoint
        List<Integer> l = new ArrayList<>();

        PriorityQueue<WeightedNode> in_exploration = new PriorityQueue<>();
        int N;

        distance[startNodeId] = 0;
        in_exploration.add(new WeightedNode(startNodeId, 0));


        boolean quit = true;
        for(int i = 0; i<graph.nodeOutDegree(endNodeId); i++){
            if(costFunction.costFactor(endNodeId, graph.nodeOutEdgeId(endNodeId, i)) != Double.POSITIVE_INFINITY){
                quit = false;
            }
        }
        if(quit) return null;

        while (!in_exploration.isEmpty()) {

            N = in_exploration.remove().nodeId;

            if (N == endNodeId)
                return buildRoute(predecessors, startNodeId, endNodeId);

            if (distance[N] == Float.NEGATIVE_INFINITY) {
                continue;
            }

            for (int i = 0; i < graph.nodeOutDegree(N); i++) {

                int edgeId = graph.nodeOutEdgeId(N, i);
                int Np = graph.edgeTargetNodeId(edgeId);

                float d = (float) (distance[N] + (graph.edgeLength(edgeId) * costFunction.costFactor(N, edgeId)));

                if (d < distance[Np]) {
                    distance[Np] = d;
                    predecessors[Np] = ((i << 28) | N); //save values in 32 bits. msb 4 bits for index of outgoing edges and the 28 other for the node id
                    in_exploration.add(new WeightedNode(Np, (float) (d + getDistanceToEnd(graph.nodePoint(Np), toPoint))));
                }
            }

            distance[N] = Float.NEGATIVE_INFINITY;
        }

        return null;
    }
}
