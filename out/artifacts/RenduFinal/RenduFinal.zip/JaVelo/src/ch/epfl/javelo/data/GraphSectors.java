package ch.epfl.javelo.data;

import ch.epfl.javelo.Math2;
import ch.epfl.javelo.projection.PointCh;

import java.awt.*;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import static ch.epfl.javelo.projection.SwissBounds.*;

/**
 * Graph sectors of javelo
 *
 * @author Jan Staszewicz (341201)
 */
public record GraphSectors(ByteBuffer buffer) {

    /**
     * sectors : 128*128 sectors (16384), swiss rectanlge 349x221km
     * a sector is therefore 2.71875x1.7265625km
     */

    /**
     * [sector...
     * [sector6][sector7][sector8]
     * [sector3][sector4][sector5]
     * [sector0][sector1][sector2]
     */

    /**
     * ByteBuffer buffer => [int id first node, short number of nodes, int id of second node, ...]
     * int id first node = 4 indexes
     * short number of nodes = 2 indexes
     * <p>
     * use getInt to combine to int from given index
     * use getShort to combine to short from given index
     */

    //Size of rectangles in meters
    private static final double LENGTHX = ((MAX_E - MIN_E) / 128);
    private static final double LENGTHY = ((MAX_N - MIN_N) / 128);

    private static final int IDNODE_LENGTH = Integer.BYTES;
    private static final int NUMBER_NODES_LENGTH = Short.BYTES;
    private static final int TOTAL_INFO_LENGTH = IDNODE_LENGTH + NUMBER_NODES_LENGTH;
    private static final int N_NODES_OFFSET = IDNODE_LENGTH;


    /**
     * Gets all the sectors intersecting a given area (squared shape) with center PointCh and length 2*distance.
     *
     * @param center   center point of searching area
     * @param distance searching distance
     * @return List of sectors that intersect the searching area
     */
    public List<Sector> sectorsInArea(PointCh center, double distance) {

        List sectors = new ArrayList<Sector>();

        int xMin = (int) ((center.e() - distance - MIN_E) / LENGTHX);
        int xMax = (int) ((center.e() + distance - MIN_E) / LENGTHX);
        int yMin = (int) ((center.n() - distance - MIN_N) / LENGTHY);
        int yMax = (int) ((center.n() + distance - MIN_N) / LENGTHY);

        //Iterate over all sectors intersecting the given area
        for (int y = yMin; y <= yMax; y++) {
            y = Math2.clamp(0, y, 127);
            for (int x = xMin; x <= xMax; x++) {
                x = Math2.clamp(0, x, 127);

                int sectorId = x + 128 * y;

                int startNodeIdIndex = sectorId * TOTAL_INFO_LENGTH;
                int startNodeId = buffer.getInt(startNodeIdIndex);

                int numberOfNodes = Short.toUnsignedInt(buffer.getShort(startNodeIdIndex + N_NODES_OFFSET));
                int endNodeId = startNodeId + numberOfNodes;

                sectors.add(new Sector(startNodeId, endNodeId));
            }
        }


        return sectors;
    }


    public record Sector(int startNodeId, int endNodeId) {
    } //endNodeId is the next node after the last one

}
