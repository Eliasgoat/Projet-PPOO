package ch.epfl.javelo.routing;

public interface CostFunction {

    /**
     * Gets factor by which edge has to be multiplied (can be Double.POSITIVE_INFINITY)
     * Must be >= 1
     *
     * @param nodeId the node id
     * @param edgeId the edge id
     *
     * @return cost factor
     */
    double costFactor(int nodeId, int edgeId);
}
