package ch.epfl.javelo.projection;

import ch.epfl.javelo.Preconditions;

import java.awt.*;

/**
 * Web Mercator point
 *
 * @author Jan Staszewicz (341201)
 */
public record PointWebMercator(double x, double y) {

    /**
     * Constructs web mercator point
     *
     * @param x coordinate
     * @param y coordinate
     */
    public PointWebMercator {
        //Checks x and y in [0,1]
        Preconditions.checkArgument(!((x < 0 || x > 1) || (y < 0 || y > 1)));

    }

    /**
     * Get point relative to zoom level
     *
     * @param zoomLevel the zoom level
     * @param x         coordinate
     * @param y         coordinate
     * @return a point web mercator with scaled x & y
     */
    public static PointWebMercator of(int zoomLevel, double x, double y) {
        return new PointWebMercator(Math.scalb(x, -(8 + zoomLevel)), Math.scalb(y, -(8 + zoomLevel)));
    }

    /**
     * Get point int swiss system
     *
     * @param pointCh the point
     * @return a web mercator point
     */
    public static PointWebMercator ofPointCh(PointCh pointCh) {
        double lon = pointCh.lon();
        double lat = pointCh.lat();

        return new PointWebMercator(WebMercator.x(lon), WebMercator.y(lat));
    }

    /**
     * Get x coordinate at current zoom level
     *
     * @param zoomLevel the zoom level
     * @return x converted
     */
    public double xAtZoomLevel(int zoomLevel) {
        return Math.scalb(x, 8 + zoomLevel);
    }

    /**
     * Get y at current zoom level
     *
     * @param zoomLevel the zoom level
     * @return y converted
     */
    public double yAtZoomLevel(int zoomLevel) {
        return Math.scalb(y, 8 + zoomLevel);
    }

    /**
     * Calculates longitude from web mercator point
     *
     * @return longitude
     */
    public double lon() {
        return WebMercator.lon(x);
    }

    /**
     * Calculates latitude from web mercator point
     *
     * @return latitude
     */
    public double lat() {
        return WebMercator.lat(y);
    }

    /**
     * Converts WebMercator point to PointCh (swiss system)
     *
     * @return PointCh
     */
    public PointCh toPointCh() {

        double lon = lon();
        double lat = lat();

        double e = Ch1903.e(lon, lat);
        double n = Ch1903.n(lon, lat);

        return SwissBounds.containsEN(e, n) ? new PointCh(e, n) : null;
    }

}
