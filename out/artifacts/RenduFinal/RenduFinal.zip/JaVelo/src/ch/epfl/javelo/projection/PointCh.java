package ch.epfl.javelo.projection;

import ch.epfl.javelo.Math2;
import ch.epfl.javelo.Preconditions;

/**
 * A point in the swiss system
 *
 * @author Jan Staszewicz (341201)
 */
public record PointCh(double e, double n) {

    /**
     * Constructs a new point in ch system
     *
     * @param e coordinate
     * @param n coordinate
     */
    public PointCh {
        //checks point is in limits
        Preconditions.checkArgument(SwissBounds.containsEN(e, n));
    }

    /**
     * Calculates squared distance to given point
     *
     * @param that other point
     * @return squared distance between the two points int meters
     */
    public double squaredDistanceTo(PointCh that) {
        return Math2.squaredNorm(e - that.e, n - that.n);
    }

    /**
     * Calculates distance to given point
     *
     * @param that other point
     * @return distance in meters
     */
    public double distanceTo(PointCh that) {
        return Math2.norm(e - that.e, n - that.n);
    }

    /**
     * Calculates longitude
     *
     * @return longitude
     */
    public double lon() {
        return Ch1903.lon(e, n);
    }

    /**
     * Calculates latitude
     *
     * @return latitude
     */
    public double lat() {
        return Ch1903.lat(e, n);
    }

}
