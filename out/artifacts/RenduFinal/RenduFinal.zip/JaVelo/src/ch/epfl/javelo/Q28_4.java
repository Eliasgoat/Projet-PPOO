package ch.epfl.javelo;

/**
 * Class for Q28_4 conversions
 *
 * @author Jan Staszewicz (341201)
 */
public final class Q28_4 {

    //non-instantiable
    private Q28_4() {
    }

    ;

    /**
     * Transforms int to Q28_4 int
     *
     * @param i the int value
     * @return int in Q28_4
     */
    public static int ofInt(int i) {
        return i << 4;
    }

    /**
     * Transforms int Q28_4 to double
     *
     * @param q28_4 the q28_4 value
     * @return double in Q28_4
     */
    public static double asDouble(int q28_4) {
        return Math.scalb((double) q28_4, -4);
    }

    /**
     * Transforms int Q28_4 to float
     *
     * @param q28_4 the q28_4 value
     * @return float in Q28_4
     */
    public static float asFloat(int q28_4) {
        return Math.scalb((float) q28_4, -4);
    }
}
