package ch.epfl.javelo.data;

import ch.epfl.javelo.Functions;
import ch.epfl.javelo.projection.PointCh;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.LongBuffer;
import java.nio.ShortBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleUnaryOperator;

/**
 * Graph data structure for JaVelo
 *
 * @author Jan Staszewicz (341201)
 */
public final class Graph {

    private final GraphNodes nodes;
    private final GraphSectors sectors;
    private final GraphEdges edges;
    private final List<AttributeSet> attributeSets;

    /**
     * Constructs a new graph data structure
     *
     * @param nodes         all graph nodes
     * @param sectors       all graph sectors
     * @param edges         all graph edges
     * @param attributeSets all attributes
     */
    public Graph(GraphNodes nodes, GraphSectors sectors, GraphEdges edges, List<AttributeSet> attributeSets) {
        this.nodes = nodes;
        this.sectors = sectors;
        this.edges = edges;
        this.attributeSets = List.copyOf(attributeSets); //immutable
    }

    /**
     * Loads nodes
     *
     * @param basePath base path of bin file
     * @return GraphNodes containing all nodes from given file
     * @throws IOException if file hasn't load correctly
     */
    public static GraphNodes loadNodes(Path basePath) throws IOException {

        Path nodesPath = basePath.resolve("nodes.bin");

        IntBuffer buffer;

        try (FileChannel channel = FileChannel.open(nodesPath)) {
            buffer = channel
                    .map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
                    .asIntBuffer();
        }

        return new GraphNodes(buffer);
    }

    /**
     * Loads sectors
     *
     * @param basePath base path of bin file
     * @return GraphSectors containing all sectors from given file
     * @throws IOException if file hasn't load correctly
     */
    public static GraphSectors loadSectors(Path basePath) throws IOException {

        Path sectorsPath = basePath.resolve("sectors.bin");

        ByteBuffer buffer;

        try (FileChannel channel = FileChannel.open(sectorsPath)) {
            buffer = channel
                    .map(FileChannel.MapMode.READ_ONLY, 0, channel.size());
        }


        return new GraphSectors(buffer);
    }


    /**
     * Loads edges
     *
     * @param basePath base path of bin file
     * @return GraphEdges containing all edges from given file
     * @throws IOException if file hasn't load correctly
     */
    public static GraphEdges loadEdges(Path basePath) throws IOException {

        Path edgesPath = basePath.resolve("edges.bin");
        Path profilesPath = basePath.resolve("profile_ids.bin");
        Path elevationsPath = basePath.resolve("elevations.bin");

        ByteBuffer edgesBuffer;
        IntBuffer profilesBuffer;
        ShortBuffer elevationsBuffer;

        //loads each
        try (FileChannel edgesChannel = FileChannel.open(edgesPath); FileChannel profilesChannel = FileChannel.open(profilesPath); FileChannel elevationsChannel = FileChannel.open(elevationsPath)) {
            edgesBuffer = edgesChannel.map(FileChannel.MapMode.READ_ONLY, 0, edgesChannel.size());
            profilesBuffer = profilesChannel.map(FileChannel.MapMode.READ_ONLY, 0, profilesChannel.size()).asIntBuffer();
            elevationsBuffer = elevationsChannel.map(FileChannel.MapMode.READ_ONLY, 0, elevationsChannel.size()).asShortBuffer();
        }

        return new GraphEdges(edgesBuffer, profilesBuffer, elevationsBuffer);
    }

    /**
     * Loads attributes
     *
     * @param basePath base path of bin file
     * @return list of attributes containing all attributes from given file
     * @throws IOException if file hasn't load correctly
     */
    public static List<AttributeSet> loadAttributes(Path basePath) throws IOException {

        Path attributesPath = basePath.resolve("attributes.bin");

        LongBuffer buffer;

        try (FileChannel channel = FileChannel.open(attributesPath)) {
            buffer = channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size()).asLongBuffer();
        }

        List<AttributeSet> list = new ArrayList<>();

        for (int i = 0; i < buffer.capacity(); i++) {
            list.add(new AttributeSet(buffer.get(i)));
        }

        return list;
    }

    /**
     * Creates the JaVelo graph obtained from files from path basePath
     *
     * @param basePath base path of bin files for the javelo app
     * @return JaVelo Graph
     * @throws IOException if files haven't loaded correctly
     */
    public static Graph loadFrom(Path basePath) throws IOException {

        //EXCEPTION IF ERROR ON FILES PROCESSING

        //Loads each objects separately
        GraphNodes new_nodes = loadNodes(basePath);
        GraphSectors new_sectors = loadSectors(basePath);
        GraphEdges new_edges = loadEdges(basePath);
        List<AttributeSet> new_attributeSets = loadAttributes(basePath);

        return new Graph(new_nodes, new_sectors, new_edges, new_attributeSets);
    }

    /**
     * Gets number of nodes in the graph
     *
     * @return number of nodes
     */
    public int nodeCount() {
        return nodes.count();
    }

    /**
     * Gets position PointCh from node of given id
     *
     * @param nodeId the node id
     * @return point PointCh of given node
     */
    public PointCh nodePoint(int nodeId) {
        return new PointCh(nodes.nodeE(nodeId), nodes.nodeN(nodeId));
    }

    /**
     * Gets number of outgoing edges from node of given id
     *
     * @param nodeId the node id
     * @return number of outgoing edges from given node
     */
    public int nodeOutDegree(int nodeId) {
        return nodes.outDegree(nodeId);
    }

    /**
     * Gets edge id by given node index from outgoing edges
     *
     * @param nodeId    the node id
     * @param edgeIndex the edge index from all outgoing edges
     * @return node id of outgoing edge
     */
    public int nodeOutEdgeId(int nodeId, int edgeIndex) {
        return nodes.edgeId(nodeId, edgeIndex);
    }

    /**
     * Gets id of the closest node to given point
     *
     * @param point          given point
     * @param searchDistance searching distance
     * @return closest node id to given point
     */
    public int nodeClosestTo(PointCh point, double searchDistance) {

        if (point == null){
            return -1;
        }

        List<GraphSectors.Sector> targeted_sectors = sectors.sectorsInArea(point, searchDistance);

        int closestId = -1; //provisional
        double closest_distance_squared = Math.pow(searchDistance, 2);

        for (GraphSectors.Sector sector : targeted_sectors) {
            for (int i = sector.startNodeId(); i < sector.endNodeId(); i++) {

                double node_distance_squared = point.squaredDistanceTo(nodePoint(i));
                if ((node_distance_squared <= closest_distance_squared)) {
                    closestId = i;
                    closest_distance_squared = node_distance_squared;
                }

            }
        }

        return closestId;
    }

    /**
     * Gets id of target node from edge by id
     *
     * @param edgeId the edge id
     * @return target node id of given edge
     */
    public int edgeTargetNodeId(int edgeId) {
        return edges.targetNodeId(edgeId);
    }

    /**
     * Checks if edge is inverted
     *
     * @param edgeId the edge id
     * @return true if inverted, false otherwise
     */
    public boolean edgeIsInverted(int edgeId) {
        return edges.isInverted(edgeId);
    }

    /**
     * Gets all OSM attributes attached to edge of given id
     *
     * @param edgeId the edge id
     * @return AttributeSet containing all attributes from given edge
     */
    public AttributeSet edgeAttributes(int edgeId) {
        return attributeSets.get(edges.attributesIndex(edgeId));
    }

    /**
     * Gets edge length
     *
     * @param edgeId the edge id
     * @return edge length
     */
    public double edgeLength(int edgeId) {
        return edges.length(edgeId);
    }

    /**
     * Gets total elevation of given edge by id
     *
     * @param edgeId the edge id
     * @return elevation from given edge
     */
    public double edgeElevationGain(int edgeId) {
        return edges.elevationGain(edgeId);
    }

    /**
     * Gets function from profiles of given edge by id
     *
     * @param edgeId the edge id
     * @return DoubleUnaryOperator function with edge profile
     */
    public DoubleUnaryOperator edgeProfile(int edgeId) {
        if (!edges.hasProfile(edgeId)) {
            return Functions.constant(Double.NaN);
        } else {
            return Functions.sampled(edges.profileSamples(edgeId), edgeLength(edgeId));
        }
    }


}
