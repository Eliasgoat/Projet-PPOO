package ch.epfl.javelo;

/**
 * Utility class used to check preconditions
 *
 * @author Jan Staszewicz (341201)
 */
public final class Preconditions {

    //non-instantiable
    private Preconditions() {
    }

    /**
     * Checks passed argument
     *
     * @param shouldBeTrue the condition/argument
     * @throws IllegalArgumentException if argument is false
     */
    public static void checkArgument(boolean shouldBeTrue) {

        if (!shouldBeTrue) {
            throw new IllegalArgumentException();
        }

    }
}
