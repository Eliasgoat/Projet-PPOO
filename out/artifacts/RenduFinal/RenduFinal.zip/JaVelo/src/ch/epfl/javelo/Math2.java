package ch.epfl.javelo;

/**
 * Utility class used for mathematical/geometrical calculations
 *
 * @author Jan Staszewicz (341201)
 */
public final class Math2 {

    //non-instantiable
    private Math2() {
    }

    /**
     * Ceiling division
     *
     * @param x first value
     * @param y second value
     * @return ceiling division of x by y
     */
    public static int ceilDiv(int x, int y) {

        Preconditions.checkArgument(!(x < 0 || y <= 0));

        return (x + y - 1) / y;
    }

    /**
     * Interpolates
     *
     * @param y0 first y
     * @param y1 second y
     * @param x  x distance
     * @return interpolation
     */
    public static double interpolate(double y0, double y1, double x) {
        return Math.fma(y1 - y0, x, y0);

    }

    /**
     * Restricts v to an interval [int]
     *
     * @param min min value
     * @param v   value to restrict
     * @param max max value
     * @return v restricted to min and max
     */
    public static int clamp(int min, int v, int max) {

        Preconditions.checkArgument(!(min > max));

        if (v > max) {
            return max;
        } else if (v < min) {
            return min;
        } else {
            return v;
        }

    }

    /**
     * Restricts v to an interval [double]
     *
     * @param min min value
     * @param v   value to restrict
     * @param max max value
     * @return v restricted to min and max
     */
    public static double clamp(double min, double v, double max) {

        Preconditions.checkArgument(!(min > max));

        if (v > max) {
            return max;
        } else if (v < min) {
            return min;
        } else {
            return v;
        }
    }

    /**
     * Calculates inverse of hyperbolic sinus
     *
     * @param x the value
     * @return arsinh of x
     */
    public static double asinh(double x) {
        return Math.log(x + Math.sqrt(1 + Math.pow(x, 2)));
    }

    /**
     * Calculates dot product
     *
     * @param uX x value of vector u
     * @param uY y value of vector u
     * @param vX x value of vector v
     * @param vY y value of vector v
     * @return dot product
     */
    public static double dotProduct(double uX, double uY, double vX, double vY) {
        return (uX * vX + uY * vY);
    }

    /**
     * Calculates squaredNorm
     *
     * @param uX x value of vector u
     * @param uY y value of vector u
     * @return squared norm of given vector
     */
    public static double squaredNorm(double uX, double uY) {
        return (Math.pow(uX, 2) + Math.pow(uY, 2));
    }

    /**
     * Calculates Norm
     *
     * @param uX x value of vector u
     * @param uY y value of vector u
     * @return norm of given vector
     */
    public static double norm(double uX, double uY) {
        return Math.sqrt(squaredNorm(uX, uY));
    }

    /**
     * Calculates projection length
     *
     * @param aX x value of point a
     * @param aY y value of point a
     * @param bX x value of point b
     * @param bY y value of point b
     * @param pX x value of point p
     * @param pY y value of point p
     * @return projection of AP on AB
     */
    public static double projectionLength(double aX, double aY, double bX, double bY, double pX, double pY) {

        //vector AP
        double apX = pX - aX;
        double apY = pY - aY;

        //vector AB
        double abX = bX - aX;
        double abY = bY - aY;

        return (dotProduct(apX, apY, abX, abY)) / norm(abX, abY);
    }
}
