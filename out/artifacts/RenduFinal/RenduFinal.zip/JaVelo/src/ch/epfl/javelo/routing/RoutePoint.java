package ch.epfl.javelo.routing;

import ch.epfl.javelo.projection.PointCh;

import javax.print.attribute.standard.MediaSize;

/**
 * A route point
 *
 * @author Jan Staszewicz (341201)
 */
public record RoutePoint(PointCh point, double position, double distanceToReference) {

    public static final RoutePoint NONE = new RoutePoint(null, Double.NaN, Double.POSITIVE_INFINITY);

    /**
     * Gets position shifted by given value
     *
     * @param positionDifference the value by which the position has to be shifted
     * @return new RoutePoint with shifted position
     */
    public RoutePoint withPositionShiftedBy(double positionDifference) {
        return new RoutePoint(point, position + positionDifference, distanceToReference);
    }

    /**
     * Gets route point with min distance to reference between two points
     *
     * @param that the other route point
     * @return route point with the smallest distance to reference
     */
    public RoutePoint min(RoutePoint that) {
        return (this.distanceToReference <= that.distanceToReference()) ? this : that;
    }

    /**
     * Gets route point with min distance to reference between two points
     *
     * @param thatPoint               the other point
     * @param thatPosition            the other point position
     * @param thatDistanceToReference the other point's distance to reference
     * @return RoutePoint
     */
    public RoutePoint min(PointCh thatPoint, double thatPosition, double thatDistanceToReference) {
        if (this.distanceToReference <= thatDistanceToReference) {
            return this;
        } else {
            return new RoutePoint(thatPoint, thatPosition, thatDistanceToReference);
        }
    }
}
