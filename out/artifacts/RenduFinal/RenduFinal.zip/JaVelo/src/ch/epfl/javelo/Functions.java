package ch.epfl.javelo;

import java.util.function.DoubleUnaryOperator;

/**
 * Functions for javelo
 *
 * @author Jan Staszewicz (341201)
 */
public final class Functions {

    //non-instantiable
    private Functions() {
    }

    /**
     * Creates a constant function
     *
     * @param y the constance value
     * @return constant function
     */
    public static DoubleUnaryOperator constant(double y) {
        return new Constant(y);
    }

    /**
     * Creates a function by linear interpolation between the values of the samples variable
     *
     * @param samples samples of elevations
     * @param xMax    max length of profile
     * @return DoubleUnaryOperator function sampled
     */
    public static DoubleUnaryOperator sampled(float[] samples, double xMax) {

        Preconditions.checkArgument(!(samples.length < 2 || xMax <= 0));

        return new Sampled(samples, xMax);
    }


    /**
     * Sampled function
     *
     * @author Jan Staszewicz (341201)
     */
    private static final class Sampled implements DoubleUnaryOperator {

        float[] samples;
        double xMax;

        /**
         * Creates a sample function
         *
         * @param samples samples of elevations
         * @param xMax    max length
         */
        public Sampled(float[] samples, double xMax) {
            this.samples = samples;
            this.xMax = xMax;
        }

        @Override
        public double applyAsDouble(double x) {

            if (x >= xMax) {
                return samples[samples.length - 1];
            } else if (x <= 0) {
                return samples[0];
            }

            double distance = xMax / (samples.length - 1);

            double x1 = ((int) (x / distance)) * distance;
            double y1 = samples[(int) (x / distance)];
            double y2 = samples[(int) (x / distance) + 1];

            double x_shifted = (double) (x - x1);

            return Math2.interpolate(y1, y2, x_shifted / distance);
        }
    }

    /**
     * Constant function
     *
     * @author Jan Staszewicz (341201)
     */
    private static final class Constant implements DoubleUnaryOperator {
        double y;

        /**
         * Creates a constant function
         *
         * @param y the constant value
         */
        public Constant(double y) {
            this.y = y;
        }

        @Override
        public double applyAsDouble(double x) {
            return y;
        }
    }


}
