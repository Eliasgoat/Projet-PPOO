package ch.epfl.javelo;

public final class Q28_4 {
    private Q28_4(){}

    /**
     *Retourne la valeur Q28.4 correspondant à l'entier donné
     * @param i entier donne
     * @return la valeur Q28.4 correspondant à l'entier donné
     */
    public static int ofInt(int i){
       return i*16;
    }

    /**
     *Retourne la valeur de type double égale à la valeur Q28.4 donnée
     * @param q28_4 valeur q28_4 donnee
     * @return la valeur de type double égale à la valeur Q28.4 donnée
     */
    public static double asDouble(int q28_4){
        return Math.scalb((double) q28_4, -4);
    }

    /**
     * Retourne la valeur de type float égale à la valeur Q28.4 donnée
     * @param q28_4 valeur q28_4 donnee
     * @return la valeur de type double égale à la valeur Q28.4 donnée
     */
    public static float asFloat(int q28_4){
        return Math.scalb(q28_4, -4);
    }

}
