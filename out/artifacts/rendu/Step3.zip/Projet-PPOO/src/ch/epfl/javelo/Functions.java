package ch.epfl.javelo;

import java.util.function.DoubleUnaryOperator;

/**
 * Classe fonctions qui permet de créer des objets représentant des fonctions mathématiques
 */

public final class Functions {
    private Functions(){}

    /**
     * Crée un objet Constant à partir d'un double pour représenter la fonction constante
     * @param y (antécédent)
     * @return un objet Constant représentant la fonction constante (image de f(y) = y)
     */
    public static DoubleUnaryOperator constant(double y) {
        return new Constant(y);
    }

    /**
     * Crée un objet Sample à partir d'un échantillon et d'une plage pour représenter une interpolation linéaire
     * @param samples (tableau de floats (échantillon)), xMax (fin de la plage couverte par l'écahntillon)
     * @return un objet Sampled représentant la fonction d'interpolation linéaire
     */
   public static DoubleUnaryOperator sampled(float[] samples, double xMax) {
        return new Sampled(samples, xMax);
    }

    /**
     * Class représentant la fonction constante
     */
    private static final class Constant implements DoubleUnaryOperator {

        private double y;
        private Constant(double y){
            this.y = y;
        }
        /**
         * Réécriture donnant l'identité de l'antécédent (c'est à dire sa valeur)
         * @param x antécédent
         * @return l'identité de x (image de f(x) = x)
         */
        @Override
        public double applyAsDouble(double x) {return y;}
    }

    /**
     * Classe représentant la fonction d'interpolation linéaire
     */
   private static final class Sampled implements DoubleUnaryOperator {

       private float[] samples;
       private double xMax;

        private Sampled(float[] samples, double xMax) {
            Preconditions.checkArgument((samples.length >= 2) && (xMax > 0));
            this.samples = samples;
            this.xMax = xMax;
        }

        /**
         * Réécriture donnant l'interpolation linéaire d'un échantillon sur une plage allant de 0 à xMax
         * @param x antécédent
         * @return l'interpolation linéaire de x
         */
        @Override
        public double applyAsDouble(double x) {
            if (xMax <= x) {
                return samples[samples.length-1];
            } else if (x < 0) {
                return samples[0];
            }
            else {
                double delta = xMax/(samples.length-1);
                int leftIndex = (int) Math.floor(x/delta);
                return Math2.interpolate(samples[leftIndex], samples[leftIndex+1], (x/delta) - leftIndex);
            }
        }
    }
}


