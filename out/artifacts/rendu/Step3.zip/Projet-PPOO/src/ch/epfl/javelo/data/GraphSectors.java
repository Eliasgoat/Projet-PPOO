package ch.epfl.javelo.data;

import java.lang.reflect.Array;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import ch.epfl.javelo.projection.PointCh;
import ch.epfl.javelo.projection.SwissBounds;

public record GraphSectors(ByteBuffer buffer) {

    private static double largeurSecteur = (SwissBounds.MAX_E - SwissBounds.MIN_E)/128;
    private static double longueurSecteur = (SwissBounds.MAX_N - SwissBounds.MIN_N)/128;

    /**
     * Retourne la liste de tous les secteurs ayant une intersection avec le carré centré au point donné et de côté égal au double de la distance donnée
     * @param center centre du carre
     * @param distance un demi de la distance d'un cote du carre
     * @return la liste de tous les secteurs ayant une intersection avec le carré centré au point donné et de côté égal au double de la distance donnée
     */
    public List<Sector> sectorsInArea(PointCh center, double distance){
        List<Sector> sectors = new ArrayList<Sector>();

        int xMin;
        int xMax;
        int yMin;
        int yMax;

        if(center.e()-distance > SwissBounds.MIN_E){
            xMin = (int) (((center.e()-distance)-SwissBounds.MIN_E)/largeurSecteur);
        }else xMin = 0;

        if(center.e()+distance < SwissBounds.MAX_E){
            xMax = (int) (((center.e()+distance)-SwissBounds.MIN_E)/largeurSecteur);
        }else xMax = 127;

        if(center.n()-distance > SwissBounds.MIN_N){
            yMin = (int) (((center.n()-distance)-SwissBounds.MIN_E)/longueurSecteur);
        }else yMin = 0;

        if(center.n()+distance < SwissBounds.MAX_E){
            yMax = (int) (((center.n()+distance)-SwissBounds.MIN_E)/longueurSecteur);
        }else yMax = 127;

        ArrayList<Integer> nombresSecteurs = new ArrayList<>();
        for(int i = xMin; i <= xMax; i++){
            for(int j = yMin; j <= yMax; j++){
                nombresSecteurs.add(i+128*j);
            }
        }

        for(int secteur : nombresSecteurs){
            sectors.add(new Sector((buffer.getInt(6*secteur)), (buffer.getInt(6*secteur))+Short.toUnsignedInt(buffer.getShort(6*secteur + 4 ))));
        }
        return sectors;
    }

    /**
     * Enregistrement Sector
     * @param startNodeId l'identité du premier nœud du secteur
     * @param endNodeId l'identité du nœud situé juste après le dernier nœud du secteur
     */
    public record Sector(int startNodeId, int endNodeId){}
}
