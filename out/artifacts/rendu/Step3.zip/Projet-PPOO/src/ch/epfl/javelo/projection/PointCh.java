package ch.epfl.javelo.projection;

import ch.epfl.javelo.Math2;
import ch.epfl.javelo.Preconditions;

/**
 * Point de la carte
 *
 * @author Mir Elias
 * @author Mehdi Torjmen
 */
public record PointCh(double e, double n) {
    /**
     * @param e coordonnee est
     * @param n coordonnee nord
     * @throws IllegalArgumentException si les coordonnees ne sont pas dans les limites suisses
     */
    public PointCh{
        Preconditions.checkArgument(SwissBounds.containsEN(e, n));
    }

    /**
     * Calucule la distance au carre entre le point that et this
     * @param that point par rapport auquel on cherche la distance au carre
     */
    public double squaredDistanceTo(PointCh that){
        return Math2.squaredNorm(that.e-this.e,that.n-this.n);
    }
    /**
     * Calucule la distance entre le point that et this
     * @param that point par rapport auquel on cherche la distance
     */
    public double distanceTo(PointCh that){
        return Math2.norm(that.e-this.e,that.n-this.n);
    }
    /**
     * @return la longitude en radians du point
     */
    public double lon(){
        return Ch1903.lon(e,n);
    }
    /**
     * @return la latitude en radians du point
     */
    public double lat(){
        return Ch1903.lat(e,n);
    }
}
