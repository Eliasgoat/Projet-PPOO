package ch.epfl.javelo;

/**
 * Preconditions
 *
 * @author Mir Elias
 * @author Mehdi Torjmen
 */
public final class Preconditions {

    private Preconditions() {}

    // Checks the paramater is true otherwise we throw an IllegalArgumentException error
    /**
     *Verifie que l'argument donne est vrai
     * @param shouldBeTrue parametre qu'on veut tester
     * @throws IllegalArgumentException si l'argument est faux
     */
     public static void checkArgument(boolean shouldBeTrue){
        if(!shouldBeTrue){
            throw new IllegalArgumentException();
        }
     }

}
