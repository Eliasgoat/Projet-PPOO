package ch.epfl.javelo;

import java.util.function.DoubleUnaryOperator;

public final class Functions {
    private Functions(){}

    /**
     * @param samples échantillon de valeurs
     * @param xMax fin de la plage couverte par l'echantillon
     * @return fonction obtenue par interpolation linéaire entre les échantillons samples,
     * espacés régulièrement et couvrant la plage allant de 0 à xMax
     */
    public static DoubleUnaryOperator sampled(float[] samples, double xMax) {
        return new Sampled(samples, xMax);
    }

    /**
     * @param y valeur constante
     * @return une fonction Contante tel que f(x) = y
     */
    public static DoubleUnaryOperator constant(double y) {
        return new Constant(y);
    }


    private static final class Constant implements DoubleUnaryOperator {

        private double y;

        private Constant(double y){
            this.y = y;
        }
        /**
         * @param x valeur dont on cherche l'image
         * @return la valeur contante y quelque soit la valeur de x
         */
        @Override
        public double applyAsDouble(double x) {return y;}
    }

   private static final class Sampled implements DoubleUnaryOperator {

        private double xMax;
       private float[] samples;

        private Sampled(float[] samples, double xMax) {
            Preconditions.checkArgument((xMax > 0) && (samples.length >= 2));
            this.xMax = xMax;
            this.samples = samples;
        }
        /**
         * @param x valeur dont on cherche l'image
         * @return la valeur de la fonction en x obtenu par interpolation lineaire de samples
         */
        @Override
        public double applyAsDouble(double x) {
            if (x < 0) {
                return samples[0];
            }else if (x >= xMax) {
                return samples[samples.length-1];
            } else {
                double delta = xMax/(samples.length-1);
                int leftIndex = ((int) Math.floor(x/delta));
                return Math2.interpolate(samples[leftIndex], samples[leftIndex+1], ((x-leftIndex*delta)/delta));
            }
        }
    }
}


