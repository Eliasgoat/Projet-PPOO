package ch.epfl.javelo.routing;

import ch.epfl.javelo.Math2;
import ch.epfl.javelo.Preconditions;
import ch.epfl.javelo.projection.PointCh;

import java.awt.*;
import java.util.*;
import java.util.List;

public final class SingleRoute implements Route{

    private final List<Edge> edges;
    private final double[] positionsAtEveryNode;
    private final double length;
    private final List<PointCh> points;

    public SingleRoute(List<Edge> edges){
        Preconditions.checkArgument(!edges.isEmpty());
        this.edges = List.copyOf(edges);
        positionsAtEveryNode = new double[edges.size() + 1];
        positionsAtEveryNode[0] = 0;
        for(int i = 0; i < edges.size(); i++){
            positionsAtEveryNode[i+1] = positionsAtEveryNode[i]+ edges.get(i).length();
        }
        double length1 = 0;
        for(Edge edge : edges){
            length1 += edge.length();
        }
        this.length = length1;
        List<PointCh> list = new ArrayList<>();
        for(Edge edge : edges){
            list.add(edge.fromPoint());
        }
        list.add(edges.get(edges.size()-1).toPoint());
        this.points= Collections.unmodifiableList(list);
    }

    @Override
    public int indexOfSegmentAt(double position) {
        return 0;
    }

    @Override
    public double length() {
        return length;
    }

    @Override
    public List<Edge> edges() {
        return edges;
    }

    @Override
    public List<PointCh> points() {
        return points;
    }

    private int binarySearchCycle(double position){
        if(position == length){
            return (positionsAtEveryNode.length - 2);
        }else if(Arrays.binarySearch(positionsAtEveryNode, position) >= 0){
            return Arrays.binarySearch(positionsAtEveryNode, position);
        }else{
            return -Arrays.binarySearch(positionsAtEveryNode, position) -2;
        }
    }
    @Override
    public PointCh pointAt(double position) {
        position = Math2.clamp(0,position, length());
        int edgeIndex = binarySearchCycle(position);
        return edges.get(edgeIndex).pointAt(position - positionsAtEveryNode[edgeIndex]);
    }

    @Override
    public double elevationAt(double position) {
        position = Math2.clamp(0,position, length());
        int edgeIndex = binarySearchCycle(position);
        return edges.get(edgeIndex).elevationAt(position - positionsAtEveryNode[edgeIndex]);
    }

    @Override
    public int nodeClosestTo(double position) {
        position = Math2.clamp(0,position, length());
        int edgeIndex = binarySearchCycle(position);
        if((position-positionsAtEveryNode[edgeIndex]) <= (positionsAtEveryNode[edgeIndex+1] - position)){
            return edges.get(edgeIndex).fromNodeId();
        }
        return edges.get(edgeIndex).toNodeId();
    }

    @Override
    public RoutePoint pointClosestTo(PointCh point) {
        List<Double> positions = new ArrayList<>();
        for(int i = 0; i< edges.size(); i++){
            double position = 0;
            if(edges.get(i).positionClosestTo(point)-edges.get(i).length() > 0){
                position = edges.get(i).length();
            }else if(edges.get(i).positionClosestTo(point) < 0){
                position = 0;
            }else{
                position = edges.get(i).positionClosestTo(point);
            }
            positions.add(position);
        }
        PointCh pointOnEdge;
        double squaredDistance = point.squaredDistanceTo(edges.get(0).pointAt(positions.get(0)));
        int indexEdgeClosest = 0;
        for(int i = 1; i< edges().size(); i++){
            if(point.squaredDistanceTo(edges.get(i).pointAt(positions.get(i))) < squaredDistance){
                squaredDistance = point.squaredDistanceTo(edges.get(i).pointAt(positions.get(i)));
                indexEdgeClosest = i;
            }
        }
        double finalPosition = positions.get(indexEdgeClosest) + positionsAtEveryNode[indexEdgeClosest];
        PointCh finalPoint = edges.get(indexEdgeClosest).pointAt(positions.get(indexEdgeClosest));
        double distanceToReference = Math.sqrt(squaredDistance);
        return new RoutePoint(finalPoint, finalPosition, distanceToReference);
    }
}
