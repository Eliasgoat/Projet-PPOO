package ch.epfl.javelo;

public final class Bits {
    private Bits(){}

    /**
     * @param value entier dont on veut l'extraction
     * @param start index du du bit initial
     * @param length taille voulu
     * @return l'entier dont le vectuer de 32 bits est extrait du vecteur de 32 bits value la plage de length bits commençant au bit d'index start, qu'elle interprète comme une valeur non-signée
     */
    public static int extractUnsigned(int value, int start, int length){
        Preconditions.checkArgument((length>0)&& (length!=32) && (start+length <=32) && (start>=0) && (start<=31));
        return (value << (32-(start+length)))>>>(32-length);
    }
    /**
     * @param value entier dont on veut l'extraction
     * @param start index du du bit initial
     * @param length taille voulu
     * @return l'entier dont le vectuer de 32 bits est extrait du vecteur de 32 bits value la plage de length bits
     * commençant au bit d'index start, qu'elle interprète comme une valeur signée en complément à deux
     */
    public static int extractSigned(int value, int start, int length){
        Preconditions.checkArgument((length>0) && (start+length<=32) && (start>=0) && (start<=31));
        return (value << (32-(start+length)))>>(32-length);
    }
}
