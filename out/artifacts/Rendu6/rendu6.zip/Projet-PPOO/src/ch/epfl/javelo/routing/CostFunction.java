package ch.epfl.javelo.routing;

public interface CostFunction {

    /**
     * @param nodeId identité du noeud de depart
     * @param edgeId identité de l'arete
     * @return le facteur par lequel la longueur de l'arête d'identité edgeId,
     * partant du nœud d'identité nodeId, doit être multipliée
     */
    public abstract double costFactor(int nodeId, int edgeId);
}
