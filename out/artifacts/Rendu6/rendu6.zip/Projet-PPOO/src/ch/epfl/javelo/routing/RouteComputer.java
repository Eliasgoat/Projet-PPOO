package ch.epfl.javelo.routing;

import ch.epfl.javelo.Preconditions;
import ch.epfl.javelo.data.Graph;
import ch.epfl.javelo.data.GraphNodes;
import ch.epfl.javelo.projection.PointCh;

import java.awt.*;
import java.util.*;
import java.util.List;

public final class RouteComputer{

    private final Graph graph;
    private final CostFunction costFunction;

    public RouteComputer(Graph graph, CostFunction costFunction) {
        this.graph = graph;
        this.costFunction = costFunction;
    }

    /**
     * @param startNodeId identité du noeud de depart
     * @param endNodeId   identité du noeud d'arrivee
     * @return l'itinéraire de coût total minimal allant du nœud d'identité startNodeId
     * au nœud d'identité endNodeId dans le graphe passé au constructeur
     */
    public Route bestRouteBetween(int startNodeId, int endNodeId) {
        Preconditions.checkArgument(startNodeId != endNodeId);
        float[] distance = new float[graph.nodeCount()];
        int[] prev = new int[graph.nodeCount()];
        Queue<WeightedNode> en_exploration = new PriorityQueue<>();

        Arrays.fill(distance, 0, distance.length, Float.POSITIVE_INFINITY);
        Arrays.fill(prev, 0, prev.length, 0);
        distance[startNodeId] = 0.f;
        WeightedNode initalNode = new WeightedNode(startNodeId, distance[startNodeId]);
        en_exploration.add(initalNode);

        while (!en_exploration.isEmpty()) {
            WeightedNode n1 = en_exploration.remove();

            if (n1.distance == Float.NEGATIVE_INFINITY) {
                continue;
            }

            if (n1.nodeId == endNodeId) {
                List<Edge> edges = new ArrayList<>();
                int index = endNodeId;
                while (index != startNodeId) {
                    int edgeIdeme = 0;
                    for (int i = 0; i < graph.nodeOutDegree(prev[index]); i++) {
                        int k = graph.nodeOutEdgeId(prev[index], i);
                        if (graph.edgeTargetNodeId(k)== index) {
                            edgeIdeme = i;
                        }
                    }
                    edges.add(Edge.of(graph, graph.nodeOutEdgeId(prev[index],edgeIdeme), prev[index], index));
                    index = prev[index];
                }
                Collections.reverse(edges);
                return new SingleRoute(edges);
            }
            for (int i = 0; i < graph.nodeOutDegree(n1.nodeId); i++) {
                int start = n1.nodeId;
                int edgeIdOfStart = graph.nodeOutEdgeId(start, i);
                float d = (float) (distance[start]
                        + costFunction.costFactor(start, edgeIdOfStart) * graph.edgeLength(edgeIdOfStart));
                if (d == Float.NEGATIVE_INFINITY) {
                    continue;
                }
                WeightedNode n2 = new WeightedNode(graph.edgeTargetNodeId(edgeIdOfStart), d);
                int end = n2.nodeId;
                if (d < distance[end]) {
                    distance[end] = d;
                    prev[end] = start;
                    en_exploration.add(n2);
                }
            }
            distance[n1.nodeId] = Float.NEGATIVE_INFINITY;
        }
        return null;
    }

    private record WeightedNode(int nodeId, float distance)
            implements Comparable<WeightedNode> {
        @Override
        public int compareTo(WeightedNode that) {
            return Float.compare(this.distance, that.distance);
        }
    }
}
