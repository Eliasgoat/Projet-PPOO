package ch.epfl.javelo.routing;

import ch.epfl.javelo.Math2;
import ch.epfl.javelo.Preconditions;
import ch.epfl.javelo.projection.PointCh;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class MultiRoute implements Route{

    private final List<Route> segments;
    private final double[] positionsAtEverySegments;
    private final double length;
    private final List<Edge> edges;
    private final List<PointCh> points;

    public MultiRoute(List<Route> segments){
        Preconditions.checkArgument(!segments.isEmpty());
        this.segments = List.copyOf(segments);
        double length1 = 0;
        for(Route route: segments){
            length1+= route.length();
        }
        this.length = length1;
        positionsAtEverySegments = new double[segments.size()+1];
        positionsAtEverySegments[0] = 0;
        for(int i = 0; i < segments.size(); i++){
            positionsAtEverySegments[i+1] = positionsAtEverySegments[i]+ segments.get(i).length();
        }
        edges = new ArrayList<>();
        for(Route route : segments){
            edges.addAll(route.edges());
        }

        List<PointCh> list = new ArrayList<>();
        for(Edge edge : edges){
            list.add(edge.fromPoint());
        }
        list.add(edges.get(edges.size()-1).toPoint());
        this.points= Collections.unmodifiableList(list);
    }

    //Index de la route dont on a la position
    private int binarySearchCycle(double position){
        if(position == length){
            return (positionsAtEverySegments.length - 2);
        }else if(Arrays.binarySearch(positionsAtEverySegments, position) >= 0){
            return Arrays.binarySearch(positionsAtEverySegments, position);
        }else{
            return -Arrays.binarySearch(positionsAtEverySegments, position) -2;
        }
    }

    @Override
    public int indexOfSegmentAt(double position) {
        position = Math2.clamp(0,position, length());
        int indexOfSegment = 0;
        for (Route route : segments){
            if(position > route.length()){
                position -= route.length();
                indexOfSegment = indexOfSegment + route.indexOfSegmentAt(position) +1;
            }else{
                indexOfSegment = indexOfSegment + route.indexOfSegmentAt(position);
                break;
            }
        }
        return indexOfSegment;
    }

    @Override
    public double length() {
        return length;
    }

    @Override
    public List<Edge> edges() {
        return edges;
    }

    @Override
    public List<PointCh> points() {
        return points;
    }

    @Override
    public PointCh pointAt(double position) {
        position = Math2.clamp(0,position, length());
        int segmentIndex = binarySearchCycle(position);
        return segments.get(segmentIndex).pointAt(position - positionsAtEverySegments[segmentIndex]);
    }

    @Override
    public double elevationAt(double position) {
        position = Math2.clamp(0,position, length());
        int segmentIndex = binarySearchCycle(position);
        return segments.get(segmentIndex).elevationAt(position - positionsAtEverySegments[segmentIndex]);
    }

    @Override
    public int nodeClosestTo(double position) {
        position = Math2.clamp(0,position, length());
        int segmentIndex = binarySearchCycle(position);
        return segments.get(segmentIndex).nodeClosestTo(position-positionsAtEverySegments[segmentIndex]);
    }

    @Override
    public RoutePoint pointClosestTo(PointCh point) {
        RoutePoint pointRoute = segments.get(0).pointClosestTo(point);
        for(Route route : segments){
            pointRoute = route.pointClosestTo(point).min(pointRoute);
        }
        return pointRoute;
    }
}
