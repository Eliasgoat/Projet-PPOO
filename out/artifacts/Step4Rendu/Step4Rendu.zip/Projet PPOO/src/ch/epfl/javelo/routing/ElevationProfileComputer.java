package ch.epfl.javelo.routing;

import ch.epfl.javelo.Preconditions;

public final class ElevationProfileComputer {

    private ElevationProfileComputer(){}

    /**
     * @param route
     * @param maxStepLength
     * @return le profil en long de l'itinéraire route,
     * en garantissant que l'espacement entre les échantillons du profil est d'au maximum maxStepLength mètres
     */
    public static ElevationProfile elevationProfile(Route route, double maxStepLength){
        Preconditions.checkArgument(maxStepLength>0);
        return null;
    }
}
